/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lógica;

import java.awt.Image;
import java.awt.Rectangle;
import javax.swing.ImageIcon;

/**
 *
 * @author Osnaider
 */
public class terminalIzq extends Rectangle{
    Image terminalIzq= new ImageIcon(getClass().getResource("/Imagenes/terminalLeft.png")).getImage();
    public boolean visible=true;
    
    public terminalIzq(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public Image getTerminalIzq() {
        return terminalIzq;
    }
    
}
