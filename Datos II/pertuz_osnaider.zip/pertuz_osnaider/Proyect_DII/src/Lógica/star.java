/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lógica;

import java.awt.Rectangle;

/**
 *
 * @author osnaiderp
 */
public class star extends Rectangle{
    String star[]={"src\\Imagenes\\star1.png","src\\Imagenes\\star1.png"
            ,"src\\Imagenes\\star2.png","src\\Imagenes\\star2.png"
            ,"src\\Imagenes\\star3.png","src\\star\\mina3.png"};
            
    public direccion starss = new direccion(star);
    
    public boolean visible=true;
    
    public star(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }
}
