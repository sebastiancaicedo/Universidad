/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lógica;

import java.awt.Image;
import java.util.ArrayList;
import javax.swing.ImageIcon;

/**
 *
 * @author osnaiderp
 */
public class direccion {
    ArrayList<ImageIcon> imagenes;
    private int size;
    private int actual;
    Image im;
    
    public direccion(String[] dir){
        imagenes = new ArrayList<ImageIcon>();
        for (String string : dir) {
            imagenes.add(new ImageIcon(string));            
        }
        size = dir.length;
        actual = -1;
    }
    
    public Image next(){
        return imagenes.get(++actual%size).getImage();
    }
}
