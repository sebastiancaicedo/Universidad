/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lógica;

import java.awt.Rectangle;

/**
 *
 * @author osnaiderp
 */
public class fondo extends Rectangle{
    public fondo(int x, int y, int width, int height) {
        super(x, y, width, height);
    }
}
