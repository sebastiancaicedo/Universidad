/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lógica;

import java.awt.Graphics2D;
import java.awt.Rectangle;

/**
 *
 * @author osnaiderp
 */
public class personaje extends Rectangle{

    String quieto[]={"src\\Imagenes\\izq1p.png","src\\Imagenes\\izq2p.png","src\\Imagenes\\izq3p.png","src\\Imagenes\\der1p.png","src\\Imagenes\\der2p.png","src\\Imagenes\\der3p.png"};
    String arriba[]={"src\\Imagenes\\up1p.png","src\\Imagenes\\up2p.png","src\\Imagenes\\up3p.png"};
    String izquierda[]={"src\\Imagenes\\izq1p.png","src\\Imagenes\\izq2p.png","src\\Imagenes\\izq3p.png"};
    String derecha[]={"src\\Imagenes\\der1p.png","src\\Imagenes\\der2p.png","src\\Imagenes\\der3p.png"};
    String abajo[]={"src\\Imagenes\\down1p.png","src\\Imagenes\\down2p.png","src\\Imagenes\\down3p.png"};

    String ganaste[]={"src\\Imagenes\\g1.png","src\\Imagenes\\g1.png","src\\Imagenes\\g2.png","src\\Imagenes\\g2.png","src\\Imagenes\\g3.png","src\\Imagenes\\g3.png","src\\Imagenes\\g4.png","src\\Imagenes\\g4.png"};
    String ataque1[]={"src\\Imagenes\\a1.png","src\\Imagenes\\a1.png"};
    String ataque2[]={"src\\Imagenes\\a2.png","src\\Imagenes\\a2.png"};
    String muriendo[]={"src\\Imagenes\\d1.png","src\\Imagenes\\d1.png"
            ,"src\\Imagenes\\d2.png","src\\Imagenes\\d2.png"
            ,"src\\Imagenes\\d3.png","src\\Imagenes\\d3.png"
            ,"src\\Imagenes\\d4.png","src\\Imagenes\\d4.png"
            ,"src\\Imagenes\\d5.png","src\\Imagenes\\d5.png"
            ,"src\\Imagenes\\d6.png","src\\Imagenes\\d6.png"};
    
    public direccion dead = new direccion(muriendo);
    public direccion atack1 = new direccion(ataque1);
    public direccion atack2 = new direccion(ataque2);
    public direccion win = new direccion(ganaste);
    public direccion up = new direccion(arriba);
    public direccion right = new direccion(derecha);
    public direccion left = new direccion(izquierda);
    public direccion still = new direccion(quieto);

    public direccion down = new direccion(abajo);

    boolean caminar=true;

    boolean muerte=false;
    
    int direccion=0;
    
    public int vx=0,vy=0;
    
    public Rectangle u;
    public Rectangle d;
    public Rectangle r;
    public Rectangle l;
    
    public personaje(int x, int y){
        super(x,y);
    }
    
    public personaje(int x, int y, int width, int height) {
        super(x, y, width, height);
        this.l = new Rectangle(x,y,1,25);
        this.u = new Rectangle(x,y,25,1);
        this.r = new Rectangle(x+25,y,1,25);
        this.d = new Rectangle(x,y+25,25,1);
        
    }

    


    public boolean getCaminar() {
        return caminar;
    }

    public void setCaminar(boolean caminar) {
        this.caminar = caminar;
    }


    public int getDireccion() {
        return direccion;
    }

    public void setDireccion(int direccion) {
        this.direccion = direccion;
    }

    public void pintar(Graphics2D g){
        switch(getDireccion()){
            case 0:
                g.drawImage(still.next(), x, y, 25, 25, null);

                break;
            case 1:
                g.drawImage(right.next(), x, y, 25, 25, null);
                break;
            case 2:
                g.drawImage(left.next(), x, y, 25, 25, null);
                break;
            case 3:
                g.drawImage(up.next(), x, y, 25, 25, null);
                break;
            case 4:
                g.drawImage(down.next(), x, y, 25, 25, null);
                break;
            case 5:
                g.drawImage(win.next(), x, y, 25, 25, null);
                break;
            case 6:
                g.drawImage(atack1.next(), x, y, 25, 25, null);
                break;
            case 7:
                g.drawImage(atack2.next(), x, y, 25, 25, null);
                break;

        }

        mover();
    }
    
    public void mover(){  
        switch(direccion){
            case 1:
                if(caminar){
                    vx=10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else {
                    vx=0;

                }
                break;
            case 2:
                if(caminar){
                    vx=-10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else {
                    vx=0;
                }
                break;
            case 3:
                if(caminar){
                    vy=-10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else {
                        vy=0;

                }
                break;
            case 4:
                if(caminar){
                    vy=10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else{
                    vy=0;
                }
                break;
        }

        
    }
     
    public void transportar(int newX, int newY){
        super.x=newX;
        super.y=newY;
        u.x=newX;
        u.y=newY;
        l.x+=newX;
        l.y=newY;
        r.x=newX;
        r.y=newY;
        d.x=newX;
        d.y=newY;
    }
    public void detenido() {
        
        if (!muerte) {
            vx=0;
            vy=0;
            direccion=0;
            caminar = false;
        }
    }
}
