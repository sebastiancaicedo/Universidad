/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lógica;

import java.awt.Image;
import java.awt.Rectangle;
import javax.swing.ImageIcon;

/**
 *
 * @author Osnaider
 */
public class caminoLibre extends Rectangle{
//    Image caminoLibre = new ImageIcon(getClass().getResource("/Imagenes/portal.png")).getImage();
//    public boolean visible=true;
    
    public caminoLibre(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

//    public void setVisible(boolean visible) {
//        this.visible = visible;
//    }
//
//    public Image getCaminoLibre() {
//        return caminoLibre;
//    }
}
