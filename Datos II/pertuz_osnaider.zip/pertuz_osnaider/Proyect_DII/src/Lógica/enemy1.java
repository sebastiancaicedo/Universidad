/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lógica;

import java.awt.Graphics2D;
import java.awt.Rectangle;

/**
 *
 * @author osnaiderp
 */
public class enemy1 extends Rectangle{
    String arriba[]={"src\\Imagenes\\up1c.png","src\\Imagenes\\up1c.png","src\\Imagenes\\up2c.png","src\\Imagenes\\up2c.png"};
    String izquierda[]={"src\\Imagenes\\izq1c.png","src\\Imagenes\\izq2c.png"};
    String derecha[]={"src\\Imagenes\\der1c.png","src\\Imagenes\\der2c.png"};
    String abajo[]={"src\\Imagenes\\down1c.png","src\\Imagenes\\down2c.png"};//aqui iba caidaa en evez de abajo
    
    public direccion up = new direccion(arriba);
    public direccion right = new direccion(derecha);
    public direccion left = new direccion(izquierda);
    public direccion down = new direccion(abajo);
    
    boolean caminar=true;

    boolean muerte=false;
    
    int direccion=0;
    
    public int vx=0,vy=0;
    
    public Rectangle u;
    public Rectangle d;
    public Rectangle r;
    public Rectangle l;
    public enemy1(int x, int y, int width, int height) {
        super(x, y, width, height);
        this.l = new Rectangle(x,y,1,25);
        this.u = new Rectangle(x,y,25,1);
        this.r = new Rectangle(x+25,y,1,25);
        this.d = new Rectangle(x,y+25,25,1);
    }

        public boolean getCaminar() {
        return caminar;
    }

    public void setCaminar(boolean caminar) {
        this.caminar = caminar;
    }


    public int getDireccion() {
        return direccion;
    }

    public void setDireccion(int direccion) {
        this.direccion = direccion;
    }
    
     public void pintar(Graphics2D g){
        switch(getDireccion()){
            case 0:
                g.drawImage(up.next(), x, y, 25, 25, null);

                break;
            case 1:
                g.drawImage(right.next(), x, y, 25, 25, null);
                break;
            case 2:
                g.drawImage(left.next(), x, y, 25, 25, null);
                break;
            case 3:
                g.drawImage(up.next(), x, y, 25, 25, null);
                break;
            case 4:
                g.drawImage(down.next(), x, y, 25, 25, null);
                break;

        }

        mover();
    } 
    public void mover(){  
        switch(direccion){
            case 1:
                if(caminar){
                    vx=10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else {
                    vx=0;

                }
                break;
            case 2:
                if(caminar){
                    vx=-10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else {
                    vx=0;
                }
                break;
            case 3:
                if(caminar){
                    vy=-10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else {
                        vy=0;

                }
                break;
            case 4:
                if(caminar){
                    vy=10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else{
                    vy=0;
                }
                break;
        }

        
    }
}
