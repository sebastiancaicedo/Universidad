/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lógica;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import javax.swing.ImageIcon;

/**
 *
 * @author osnaiderp
 */
public class bloqueV extends Rectangle{
    Image bloqueV = new ImageIcon(getClass().getResource("/Imagenes/bloqueV.png")).getImage();
    
    //public Direcciones bloquess = new Direcciones(bloques);
    
    public boolean visible=true;
    
    public bloqueV(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public Image getBloqueV() {
        return bloqueV;
    }
}
