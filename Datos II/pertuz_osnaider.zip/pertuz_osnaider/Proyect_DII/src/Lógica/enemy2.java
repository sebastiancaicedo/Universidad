/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lógica;

import java.awt.Rectangle;

/**
 *
 * @author osnaiderp
 */
public class enemy2 extends Rectangle{
    String arriba[]={"src\\Imagenes\\up1cr.png","src\\Imagenes\\up1cr.png","src\\Imagenes\\up2cr.png","src\\Imagenes\\up2cr.png"};
    String izquierda[]={"src\\Imagenes\\izq1cr.png","src\\Imagenes\\izq2cr.png"};
    String derecha[]={"src\\Imagenes\\der1cr.png","src\\Imagenes\\der2cr.png"};
    String abajo[]={"src\\Imagenes\\down1cr.png","src\\Imagenes\\down2cr.png"};//aqui iba caidaa en evez de abajo
    
    public direccion up = new direccion(arriba);
    public direccion right = new direccion(derecha);
    public direccion left = new direccion(izquierda);
    public direccion fall = new direccion(abajo);
    
    
    public enemy2(int x, int y, int width, int height) {
        super(x, y, width, height);
    }
}
