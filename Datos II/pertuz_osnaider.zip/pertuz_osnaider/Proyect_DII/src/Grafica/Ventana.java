/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Grafica;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Osnaider
 */
public class Ventana extends javax.swing.JFrame {

    static escenario[] escenario = new escenario[10];
    
    public static int actual=0;
    public static int anterior=0;
    public static int punt=0;
    
    public static void llenar(){
        escenario[0] = new inicio();
        escenario[1] = new map1();
        escenario[2] = new map2();
        escenario[3] = new map3();
        escenario[4] = new nivel1();
        escenario[5] = new nivel2();
        escenario[6] = new nivel3();
        escenario[7] = new ganar();
        for (int i = 0; i < 4; i++) {
            escenario[i].leer();
        }
        escenario[7].leer();
    }
    
    public Ventana() {
        initComponents();
        canvas1.setBackground(Color.GRAY);
        
        llenar();
        
        Thread motorgrafico = new Thread(new Runnable() {
            
            
            @Override
            public void run() {
                canvas1.createBufferStrategy(2);
                
                while(true){
                    Graphics2D g = (Graphics2D) canvas1.getBufferStrategy().getDrawGraphics();
                    
                    g.clearRect(0, 0, 736, 768);
                    
                    escenario[actual].pintar(g);
                    
                    canvas1.getBufferStrategy().show();
                    
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Ventana.class.getName()).log(Level.SEVERE, null, ex);
                    }
                
                }
                
            }
            
        });
        
         motorgrafico.start();
       
        canvas1.addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent ke) {
                
            }

            @Override
            public void keyPressed(KeyEvent ke) {

                escenario[actual].keyPressed(ke);
                
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                
                escenario[actual].keyReleased(ke);
                
            }

        });
        escenario[actual].sonar();
        canvas1.requestFocus();
    }
    
     public static void actualizar(int escena){
        escenario[actual].detener();
        actual=escena;
        escenario[actual].sonar();
//        if(ant==3){
//            escenario[actual].detener();
//            actual=0;
//            escenario[actual].sonar();
//        }else{
//            escenario[actual].detener();
//        actual=escena;
//        escenario[actual].sonar();
//        }
    }
     
       public static void actualizarPunt(int puntaje){
        punt=puntaje;
    }
    public int getPuntaje() {
        return punt;
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        canvas1 = new java.awt.Canvas();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        canvas1.setPreferredSize(new java.awt.Dimension(768, 736));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(canvas1, javax.swing.GroupLayout.DEFAULT_SIZE, 512, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(canvas1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 439, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                Ventana v = new Ventana();
                v.pack();
                v.setBounds(0, 0, 736, 768);
                Dimension dim= Toolkit.getDefaultToolkit().getScreenSize();
                Dimension di= v.getSize();
                v.setLocation((dim.width - di.width)/2,(dim.height - di.height-100)/2);
                v.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Canvas canvas1;
    // End of variables declaration//GEN-END:variables
}
