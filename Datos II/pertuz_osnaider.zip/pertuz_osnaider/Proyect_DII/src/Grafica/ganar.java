/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Grafica;

import Lógica.fondo;
import Lógica.sonido;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;

/**
 *
 * @author Osnaider
 */
public class ganar extends escenario{
     public static int actual=4;
    
    
    Image fondo = new ImageIcon(getClass().getResource("/Imagenes/ganaste.png")).getImage();
    public sonido sonido;

    public ganar() {
        sonido = new sonido("Complete",0);
    }
    
    @Override
    public void sonar(){
        try {
            sonido.Sonar();
        } catch (UnsupportedAudioFileException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (LineUnavailableException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void detener() {
        sonido.detener();
    }
    
    @Override
    public void pintar(Graphics2D g){
       
        g.drawImage(fondo,0,0,736, 768,null);
//        pintarmapa(g);
//        p.setDireccion(5);
//        p.pintar(g);
        
    }
    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.VK_ENTER){
            if(actual<7){
            //Ventana.actualizar(++actual);
              Ventana.actualizar(actual+1);
            }
            if(actual==3){
            Ventana.actualizar(0);
            }
        }
    }
}
