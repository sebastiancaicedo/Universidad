/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Grafica;

import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

/**
 *
 * @author Osnaider
 */
public class escenario {
    
    public void trasladar(){
    }

    public void leer(){
    }
    
    public void sonar(){
    }
    
    public void detener(){
    }
    
    public void pintar(Graphics2D g){  
    }
    
    public void keyPressed(KeyEvent e) {
    }

    public void keyReleased(KeyEvent e) {
    }

    public void keyTyped(KeyEvent e) {
    }
}
