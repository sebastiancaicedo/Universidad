/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Grafica;

import Lógica.*;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 *
 * @author Osnaider
 */
public class map1 extends escenario{
    String ruta="src/Escenarios/map1.txt";
    //String ruta;
    public File myFile = new File(ruta);
   // public File myFile = new File("src/Escenarios/map1.txt");
    public ArrayList<String> punt = new ArrayList();
    ArrayList<String> puntajesG= new ArrayList<String>();
    ArrayList<bloqueV> bloquesV = new ArrayList<bloqueV>();
    
    ArrayList<bloqueH> bloquesH= new ArrayList<bloqueH>();
    
    ArrayList<caminoLibre> caminosLibres = new ArrayList<caminoLibre>();
    ArrayList<terminalIzq> terminalesIzq = new ArrayList<terminalIzq>();
    ArrayList<terminalDer> terminalesDer = new ArrayList<terminalDer>();
    ArrayList<terminalUp> terminalesUp = new ArrayList<terminalUp>();
    ArrayList<terminalDown> terminalesDown = new ArrayList<terminalDown>();
    ArrayList<star> stars = new ArrayList<star>();
    int restantesS;
    ArrayList<ministar> ministars = new ArrayList<ministar>();
    int restantesM;
    ArrayList<portal> portales = new ArrayList<portal>();
    personaje p;
    enemy1 enemy1;
    enemy2 enemy2;
    barra barra;
    int puntaje=Ventana.punt;
    int puntMax;
    public void setRuta(String ruta) {
        this.ruta = ruta;
    }
    public sonido sonido;
     @Override
    public void sonar(){
        try {
            sonido.Sonar();
        } catch (UnsupportedAudioFileException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (LineUnavailableException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void detener() {
        sonido.detener();
    }
    
    public map1(){
        sonido = new sonido("Theme",0);
    }
    
    String[][] map1 = new String[24][23];
    //Rectangle pantalla = new Rectangle(0,0,736, 768);
    public void llenarMap(String[] fila, int numFila){
        for(int i=0; i< fila.length; i++){
            if(fila[i].contains("1")){
                bloquesH.add(new bloqueH(32*i,32*numFila,32,32));
                //cantBloquesH++;
                map1[numFila][i]="1"; 
            }
            if(fila[i].contains("2")){
                bloquesV.add(new bloqueV(32*i,32*numFila,32,32));
                //cantBloquesV++;
                map1[numFila][i]="2"; 
            }
            if(fila[i].contains("7")){
                barra= new barra(32*i,32*numFila,32,32);
                map1[numFila][i]="7"; 
            }
            if(fila[i].contains("0")){
                ministars.add(new ministar(32*i,32*numFila,32,32));
                map1[numFila][i]="0"; 
                restantesM++;
            }
            if(fila[i].contains("x")){
                caminosLibres.add(new caminoLibre(32*i,32*numFila,32,32));
                map1[numFila][i]="x"; 
            }
//            if(fila[i].contains("n")){
//                portales.add(new portal(32*i,32*numFila,32,32));
//                map1[numFila][i]="n"; 
//            }
            if(fila[i].contains("3")){
                terminalesIzq.add(new terminalIzq(32*i,32*numFila,32,32));
                map1[numFila][i]="3"; 
            }
            if(fila[i].contains("4")){
                terminalesDer.add(new terminalDer(32*i,32*numFila,32,32));
                map1[numFila][i]="4"; 
            }
            if(fila[i].contains("5")){
                terminalesUp.add(new terminalUp(32*i,32*numFila,32,32));
                map1[numFila][i]="5"; 
            }
            if(fila[i].contains("6")){
                terminalesDown.add(new terminalDown(32*i,32*numFila,32,32));
                map1[numFila][i]="6"; 
            }
            if(fila[i].contains("s")){
                stars.add(new star(32*i,32*numFila,32,32));
                map1[numFila][i]="s"; 
                restantesS++;
            }
            if(fila[i].contains("e")){
                enemy1= new enemy1(32*i,32*numFila,32,32);
                map1[numFila][i]="e"; 
            }
            if(fila[i].contains("f")){
                enemy2= new enemy2(32*i,32*numFila,32,32);
                map1[numFila][i]="f"; 
            }
            if(fila[i].contains("p")){
                p = new personaje(32*i,32*numFila,32,32);
                map1[numFila][i]="p";
            }
        }
       cargarPuntajes(); 
    }
    
    @Override
    public void leer(){
        
        String temp;
        String[] temp_read;
        int posy=0;
        
        try{
            FileReader fin = new FileReader(myFile);
            BufferedReader myread = new BufferedReader(fin);

            temp = myread.readLine();
            
            do{
                temp_read = temp.split(",");
                llenarMap(temp_read, posy);
                posy++;
            }while((temp = myread.readLine())!=null);

            myread.close();
            fin.close();

        }catch(Exception ex){ex.printStackTrace();}
    }
    
    public void pintarMap(Graphics2D g){
        //g.clearRect(0, 0, 736, 768);
        //puntaje+=puntaje;
        for (int i = 0; i < bloquesV.size(); i++) {
            g.drawImage(bloquesV.get(i).getBloqueV(), bloquesV.get(i).x, bloquesV.get(i).y, 32, 32, null);
        }
        for (int i = 0; i < bloquesH.size(); i++) {
            g.drawImage(bloquesH.get(i).getBloqueH(), bloquesH.get(i).x, bloquesH.get(i).y, 32, 32, null);
        }
        for (int i = 0; i < terminalesIzq.size(); i++) {
            g.drawImage(terminalesIzq.get(i).getTerminalIzq(), terminalesIzq.get(i).x,terminalesIzq.get(i).y, 32, 32, null);
        }
        for (int i = 0; i < terminalesDer.size(); i++) {
            g.drawImage(terminalesDer.get(i).getTerminalDer(), terminalesDer.get(i).x,terminalesDer.get(i).y, 32, 32, null);
        }
        for (int i = 0; i < terminalesUp.size(); i++) {
            g.drawImage(terminalesUp.get(i).getTerminalUp(), terminalesUp.get(i).x,terminalesUp.get(i).y, 32, 32, null);
        }
        for (int i = 0; i < terminalesDown.size(); i++) {
            g.drawImage(terminalesDown.get(i).getTerminalDown(), terminalesDown.get(i).x,terminalesDown.get(i).y, 32, 32, null);
        }

        for (int i = 0; i < stars.size(); i++) {
            g.drawImage(stars.get(i).starss.next(), stars.get(i).x, stars.get(i).y, stars.get(i).width,stars.get(i).height, null);
        }
        for (int i = 0; i < ministars.size(); i++) {
            g.drawImage(ministars.get(i).getMinistar(), ministars.get(i).x, ministars.get(i).y, 32, 32, null);
        }
//        for (int i = 0; i < portales.size(); i++) {
//            g.drawImage(portales.get(i).getPortal(), portales.get(i).x, portales.get(i).y, 32, 32, null);
//        }
//        for (int i = 0; i < caminosLibres.size(); i++) {
//            g.drawImage(caminosLibres.get(i).getCaminoLibre(), caminosLibres.get(i).x, caminosLibres.get(i).y, 32, 32, null);
//        }
        g.drawImage(barra.getBarra(), barra.x, barra.y, 32, 32, null);
        //g.drawImage(enemy1.up.next(), enemy1.x, enemy1.y, 32, 32, null);
        g.drawImage(enemy2.up.next(), enemy2.x, enemy2.y, 32, 32, null);
        //g.drawImage(p.left.next(), p.x, p.y, 32, 32, null);
        g.drawString("High Score:"+puntMax, 25, 25);
        g.drawString("Puntaje: "+puntaje, 200, 25);
        
    }
    
    public void pintar(Graphics2D g){
        //direccionEnemy();
        pintarMap(g);

        //for (int i = 0; i < 4; i++) {
            if(enemy1.intersects(p)){
                for (int j = 0; j < 12; j++) {
                    g.drawImage(p.dead.next(), p.x, p.y, 32, 32, null);
                }
                Ventana.actualizar(4);
                Ventana.llenar();
                if(puntaje>puntMax){
                    puntMax=puntaje;
                }
            }
            if(enemy2.intersects(p)){
                for (int j = 0; j < 12; j++) {
                    g.drawImage(p.dead.next(), p.x, p.y, 32, 32, null);
                }
                Ventana.actualizar(4);
                Ventana.llenar();
            }
        //}
        direccionEnemy(g);
        if((restantesM-16)>0 || restantesS>0){   
        //if(restantesS-3>0){
        switch(p.getDireccion()){
            case 0:
                p.detenido();
                break;
            case 1:
                    //comprobar1(g);//comprobarDer
                    comprobar(g, p.r, 10, 0); //da igual p.r o p
                    comprobarE(g, enemy1.r, 10, 0);
                break;
            case 2:
                    //comprobar2(g);
                    comprobar(g, p.l, -10, 0);
                    comprobarE(g, enemy1.l, -10, 0);
                break;
            case 3:

                //comprobar3();
                comprobar(g, p.u, 0,-10);
                comprobarE(g, enemy1.u, 0, -10);
                break;
            case 4:

                //comprobar4();
                comprobar(g, p.d,0, 10);
                comprobarE(g, enemy1.d, 0, 10);
                break;

        }

        p.pintar(g);
        enemy1.pintar(g);
        }else{
            Ventana.actualizarPunt(puntaje);
            ganar.actual=4;
            //ruta=
            Ventana.actualizar(7);
            
            punt.add(""+puntaje);
            punt.add(""+puntMax);
            guardarPuntajes();
        }
    }
    
     public void cargarPuntajes(){
        try {  
            puntajesG= lector("puntajes.txt");
            puntaje=Integer.parseInt(puntajesG.get(0));
            puntMax=Integer.parseInt(puntajesG.get(1));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(map1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     public ArrayList lector(String ruta) throws FileNotFoundException{ 
        File archivo = new File(ruta);
        FileReader leerArchiv=new FileReader(archivo);  
        BufferedReader lineaArchivo=new BufferedReader(leerArchiv); 
        
        ArrayList<String> Lineas=new ArrayList<String>();
        
        while(true){ 
            String line; 
            try{ 
                line=lineaArchivo.readLine(); 
                if(line == null){
                   break;
                }
            }catch(IOException e){
                line="";
            }  
            Lineas.add(line); 
                
        }
        try {
            lineaArchivo.close();
            leerArchiv.close();
        } catch (IOException ex) {
            Logger.getLogger(map1.class.getName()).log(Level.SEVERE, null, ex);
        }

        return Lineas;
        
    }
    
     public void guardarPuntajes(){
        try {
            escritor(punt, "puntajes.txt");
        } catch (IOException ex) {
            Logger.getLogger(map1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   public void escritor(ArrayList A, String ruta) throws IOException{
        File archivo = new File(ruta);
        if (archivo.exists()){
            archivo.delete();
        }
        
        archivo.createNewFile();
        
        FileWriter escritor = new FileWriter(archivo,true);
       
        BufferedWriter writer = new BufferedWriter(escritor); 

        for (int i = 0; i < A.size(); i++) {
            writer.write(A.get(i).toString());
            writer.newLine();
        }
        
        writer.close();
        escritor.close(); 
    }
    
    void comprobar(Graphics2D g, Rectangle dir, int cX, int cY){ //comprobarDer
        p.setCaminar(true);
        for(int i=0; i<ministars.size(); i++){
            //if(p.intersects(ministars.get(i))){
            if(ministars.get(i).intersects(p)){
                restantesM--;
                puntaje=puntaje+10;
                p.setCaminar(true);
                ministars.get(i).translate(1000, 1000);
            }
        }
        for(int i=0; i<stars.size(); i++){
            //if(p.intersects(stars.get(i))){
            if(stars.get(i).intersects(p)){
                restantesS--;
                puntaje=puntaje+40;
                p.setCaminar(true);
                stars.get(i).translate(1000, 1000);
            }
        }
        for(int i=0; i<bloquesH.size(); i++){
            if(bloquesH.get(i).intersects(dir.x+cX, dir.y+cY, dir.width, dir.height)){
                p.setCaminar(false);
            }
        }
        for(int i=0; i<bloquesV.size(); i++){
            if(bloquesV.get(i).intersects(dir.x+cX, dir.y+cY, dir.width, dir.height) ){
                p.setCaminar(false);
            }
        }
        for(int i=0; i<terminalesDer.size(); i++){
            if(terminalesDer.get(i).intersects(dir.x+cX, dir.y+cY, dir.width, dir.height)){
                p.setCaminar(false);
            }
        }
        for(int i=0; i<terminalesIzq.size(); i++){
            if(terminalesIzq.get(i).intersects(dir.x+cX, dir.y+cY, dir.width, dir.height)){
                p.setCaminar(false);
            }
        }
        for(int i=0; i<terminalesUp.size(); i++){
            if(terminalesUp.get(i).intersects(dir.x+cX, dir.y+cY, dir.width, dir.height)){
                p.setCaminar(false);
            }
        }
        for(int i=0; i<terminalesDown.size(); i++){
            if(terminalesDown.get(i).intersects(dir.x+cX, dir.y+cY, dir.width, dir.height)){
                p.setCaminar(false);
            }
        }
        
        for (int i = 0; i < caminosLibres.size(); i++) {
            if(caminosLibres.get(i).intersects(dir)){
               // p.setEscalar(true);
                p.setCaminar(true);
            }
        }

//        if(portales.get(0).intersects(dir)){
//                p.transportar(32*21,32*11);
//        }
//        if(portales.get(1).intersects(dir)){
//            p.transportar(32,32*11);
//        }

    }
    
     void comprobarE(Graphics2D g, Rectangle dir, int cX, int cY){ //comprobarDer
        enemy1.setCaminar(true);
        for(int i=0; i<bloquesH.size(); i++){
            if(bloquesH.get(i).intersects(dir.x+cX, dir.y+cY, dir.width, dir.height)){
                enemy1.setCaminar(false);
            }
        }
        for(int i=0; i<bloquesV.size(); i++){
            if(bloquesV.get(i).intersects(dir.x+cX, dir.y+cY, dir.width, dir.height) ){
                enemy1.setCaminar(false);
            }
        }
        for(int i=0; i<terminalesDer.size(); i++){
            if(terminalesDer.get(i).intersects(dir.x+cX, dir.y+cY, dir.width, dir.height)){
                enemy1.setCaminar(false);
            }
        }
        for(int i=0; i<terminalesIzq.size(); i++){
            if(terminalesIzq.get(i).intersects(dir.x+cX, dir.y+cY, dir.width, dir.height)){
                enemy1.setCaminar(false);
            }
        }
        for(int i=0; i<terminalesUp.size(); i++){
            if(terminalesUp.get(i).intersects(dir.x+cX, dir.y+cY, dir.width, dir.height)){
                enemy1.setCaminar(false);
            }
        }
        for(int i=0; i<terminalesDown.size(); i++){
            if(terminalesDown.get(i).intersects(dir.x+cX, dir.y+cY, dir.width, dir.height)){
                enemy1.setCaminar(false);
            }
        }
        
         for (int i = 0; i < caminosLibres.size(); i++) {
            if(caminosLibres.get(i).intersects(dir)){
                enemy1.setCaminar(true);
            }
        }
    }
    
     @Override
    public void keyPressed(KeyEvent e) {
        switch(e.getKeyCode()){
            case KeyEvent.VK_RIGHT:
                if(p.getDireccion()==0)
                    p.setDireccion(1);
                    //p.setCaminar(false);
                break;
            case KeyEvent.VK_LEFT:
                if(p.getDireccion()==0)
                    p.setDireccion(2);
                    p.setCaminar(true);
                break;
            case KeyEvent.VK_UP:
                if(p.getDireccion()==0)
                    p.setDireccion(3);
                    p.setCaminar(true);
                break;
            case KeyEvent.VK_DOWN:
                if(p.getDireccion()==0)
                    p.setDireccion(4);
                    p.setCaminar(true);
                break;

                }
    }

    @Override
    public void keyReleased(KeyEvent e) {
       p.detenido();
       //p.setCaminar(false);
    }
    
    public void direccionEnemy(Graphics2D g){
        if(p.x > enemy1.x && p.y > enemy1.y){
            comprobarE(g, enemy1, 10, 0);
            if(enemy1.getCaminar()){
            enemy1.setDireccion(1);
            }else{
                comprobarE(g, enemy1, 0, 10);  
                if(enemy1.getCaminar()){
                    enemy1.setDireccion(4);
                }
            }
        }
        if(p.x > enemy1.x && p.y < enemy1.y){
            //enemy1.setDireccion(2);
            comprobarE(g, enemy1, 10, 0);
            if(enemy1.getCaminar()){
            enemy1.setDireccion(2);
            }else{
                comprobarE(g, enemy1, 0, -10);  
                if(enemy1.getCaminar()){
                    enemy1.setDireccion(3);
                }
            }
        }
        if(p.x < enemy1.x && p.y > enemy1.y){
            //enemy1.setDireccion(1);
            comprobarE(g, enemy1, -10, 0);
            if(enemy1.getCaminar()){
            enemy1.setDireccion(2);
            }else{
                comprobarE(g, enemy1, 0, 10);  
                if(enemy1.getCaminar()){
                    enemy1.setDireccion(4);
                }
            }
        }
        if(p.x < enemy1.x && p.y < enemy1.y){
           //enemy1.setDireccion(2);
            comprobarE(g, enemy1, -10, 0);
            if(enemy1.getCaminar()){
            enemy1.setDireccion(1);
            }else{
                comprobarE(g, enemy1, 0, -10);  
                if(enemy1.getCaminar()){
                    enemy1.setDireccion(3);
                }
            }
        }
//        if(p.x >= enemy1.x){
//            if(p.y >= enemy1.y){
//              if(enemy1.getCaminar()){
//                enemy1.setDireccion(1);
//              }else{
//              enemy1.setDireccion(4);
//              }
//            }else{
//                if(enemy1.getCaminar()){
//                enemy1.setDireccion(1);
//              }else{
//              enemy1.setDireccion(3);
//              }
//            }         
//        }else{
//            if(p.y> enemy1.y){
//                if(enemy1.getCaminar()){
//                    enemy1.setDireccion(2);
//                }else{
//                enemy1.setDireccion(4);
//                }
//            }else{
//                if(enemy1.getCaminar()){
//                enemy1.setDireccion(2);
//              }else{
//              enemy1.setDireccion(3);
//              }
//            }
//        }
    }
}
