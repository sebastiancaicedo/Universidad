/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Grafica;

import Lógica.sonido;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;

/**
 *
 * @author Osnaider
 */
public class inicio extends escenario{
    public Image inicio = new ImageIcon(getClass().getResource("/Imagenes/Inicio.png")).getImage();
    int time=0;
    public sonido sonido;
    
    public Image getImagInicio(){
        return inicio;
    }
    
    public inicio(){
        sonido = new sonido("Title",0);
    }
    
    @Override
    public void pintar(Graphics2D g){
        
        
        g.drawImage(inicio,0,0,736,768,null);
       
        
//        if(time%10==0){
//           g.drawImage(punto,256,408,null);
//        }
        
//        if(time%20==0){
//           g.clearRect(256, 408, 16, 17);
//        }
        
    }
    
    @Override
    public void sonar(){
        try {
            sonido.Sonar();
        } catch (UnsupportedAudioFileException ex) {
            Logger.getLogger(inicio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(inicio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (LineUnavailableException ex) {
            Logger.getLogger(inicio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void detener() {
        sonido.detener();
    }
    
    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.VK_ENTER){
           // Ventana.actualizar(4);
            Ventana.actualizar(4);
        }
    }
}
