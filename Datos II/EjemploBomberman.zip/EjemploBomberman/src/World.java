
import java.awt.Color;
import java.awt.Graphics;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lgguzman
 */
public class World {
    
    public int world[][];
    public int tam;
    
    public World(int [][]world,int tam){
        this.world=world;
        this.tam=tam;
    }
    
    public void draw(Graphics g){
        
        for (int i = 0; i < world.length; i++) {
            for (int j = 0; j < world.length; j++) {
                switch(world[i][j]){
                    case 1:{
                        g.setColor(Color.red);
                        g.fillRect(j*tam,i*tam,tam,tam);
                        System.out.println("rojo "+i+" "+"j");
                        break;
                    }
                   case 0:{
                        g.setColor(Color.WHITE);
                        g.fillRect(j*tam,i*tam,tam,tam);
                        System.out.println("blanco "+i+" "+"j");
                        break;
                    }
                        
                }
            }
        }
    }
    
    
}
