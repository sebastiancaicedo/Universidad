
import java.awt.Graphics;
import javax.swing.ImageIcon;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lgguzman
 */
public class Bomberman {
    
    public static final int UP=0;
    public static final int RIGTH=1;
    public static final int DOWN=2;
    public static final int LEFT=3;
    public static final int NONE=-1;
    
    
    Animation[] animations;
    int x;
    int y;
    int vx;
    int vy;
    String path;
    int currentAnimation;
    int currentDirection;
    
    public Bomberman(int x, int y, int vx, int vy, String path){
        this.path=path;
        this.x=x;
        this.y=y;
        this.vx=vx;
        this.vy=vy;
        this.currentDirection=-1;
        animations=new Animation[4];
        
    }
    
    public int getMatrixPositionX(int x, int tam){
        return x/tam;
    }
    
    public int getMatrixPositionY(int y, int tam){
        return y/tam;
    }
    
    public void loadPics(String[] names)throws Exception{
        for (int j=0;j<4;j++) {
            String name=names[j];
            animations[j]=new Animation();
            for (int i = 1; i <= 5; i++) {
                System.out.println(path+"//"+name+i+".png");
                animations[j].addScene(
                new ImageIcon(getClass().getResource(path+"//"+name+i+".png")).getImage()        
                        , 100);
            }
        }
       
    }
    
    public boolean isValid(int [][]matrix, int tam, int x, int y){
          
         return  matrix[getMatrixPositionY(y, tam)][getMatrixPositionX(x, tam)]==0;
    }
    
    public void moveRigth(long time, int [][]matrix, int tam){
        
        if(isValid(matrix, tam, x+vx+animations[currentAnimation].getImage().getWidth(null), y)){
            x+=vx;
            currentAnimation=Bomberman.RIGTH;
            animations[Bomberman.RIGTH].update(time);
        }
    }
    
    public void moveLeft(long time, int [][]matrix, int tam){
        
        if(isValid(matrix, tam, x-vx, y)){
        x-=vx;
        currentAnimation=Bomberman.LEFT;
        animations[Bomberman.LEFT].update(time);
        }
    }
    
     public void moveUp(long time, int [][]matrix,int tam){
         if(isValid(matrix, tam, x, y-vy)){
         y-=vy;
        currentAnimation=Bomberman.UP;
        animations[Bomberman.UP].update(time);
         }
    }
     
     public void moveDown(long time, int [][]matrix, int tam){
        if(isValid(matrix, tam, x, y+vy+animations[currentAnimation].getImage().getHeight(null))){
         
        y+=vy;
        currentAnimation=Bomberman.DOWN;
        animations[Bomberman.DOWN].update(time);
        }
    }
     
     public void draw(Graphics g){
         g.drawImage(animations[currentAnimation].getImage(),x,y,null);
     }
    
}
