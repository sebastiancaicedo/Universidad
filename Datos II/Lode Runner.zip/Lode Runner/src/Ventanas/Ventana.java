
package Ventanas;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Ventana extends javax.swing.JFrame {

    static escenarios[] escenarios = new escenarios[10];
    
    public static int actual=0;
    
    public static void llenar(){
        escenarios[0] = new fondo();
        escenarios[1] = new mapa1();
        escenarios[2] = new mapa2();
        escenarios[3] = new mapa3();
        escenarios[4] = new nivel1();
        escenarios[5] = new nivel2();
        escenarios[6] = new nivel3();
        escenarios[7] = new ganar();
        for (int i = 0; i < 4; i++) {
            escenarios[i].leer();
        }
        escenarios[7].leer();
    }
    
    public Ventana() {
        
        initComponents();
        canvas1.setBackground(Color.BLACK);
        
        llenar();
        
        Thread motorgrafico = new Thread(new Runnable() {
            
            
            @Override
            public void run() {
                canvas1.createBufferStrategy(2);
                
                while(true){
                    Graphics2D g = (Graphics2D) canvas1.getBufferStrategy().getDrawGraphics(); 

                    escenarios[actual].pintar(g);
                    
                    canvas1.getBufferStrategy().show();
                    
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Ventana.class.getName()).log(Level.SEVERE, null, ex);
                    }
                
                }
                
            }
            
        });
        
        motorgrafico.start();
       
        canvas1.addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent ke) {
                
            }

            @Override
            public void keyPressed(KeyEvent ke) {

                escenarios[actual].keyPressed(ke);
                
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                
                escenarios[actual].keyReleased(ke);
                
            }

        });
        escenarios[actual].sonar();
        canvas1.requestFocus();
    }
    
    public static void actualizar(int escena){
        escenarios[actual].detener();
        actual=escena;
        escenarios[actual].sonar();
    }
    
    

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        canvas1 = new java.awt.Canvas();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(canvas1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(canvas1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

   public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
               Ventana v = new Ventana();
               v.pack();
               v.setBounds(0,0, 800, 600);
               Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
               Dimension di = v.getSize();
               v.setLocation((d.width - di.width)/2,(d.height - di.height-100)/2);
               v.setVisible(true);
               
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Canvas canvas1;
    // End of variables declaration//GEN-END:variables
}
