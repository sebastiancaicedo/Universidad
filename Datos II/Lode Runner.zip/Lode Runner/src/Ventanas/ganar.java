
package Ventanas;

import Clases.*;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;

public class ganar extends escenarios{
    
    public File myFile = new File("src/escenarios/ganar.txt");
    //File myFile = new File("E:\\Uninorte\\Sistema\\Estructuras de Datos 2\\Lode Runner\\src\\escenarios\\mapa1.txt");
    
    ArrayList<bloque> bloques = new ArrayList<bloque>();
    int zisebloque;
    ArrayList<escalera> escaleras = new ArrayList<escalera>();
    int ziseescalera;
    ArrayList<vacio> vacios = new ArrayList<vacio>();
    int zisevacio;
    personaje p; 
    public static int actual=4;
    
    
    Image fondo = new ImageIcon(getClass().getResource("/Imagenes/ganaste.png")).getImage();
    public sonido sonido;

    public ganar() {
        sonido = new sonido("Complete",0);
    }
    
    @Override
    public void sonar(){
        try {
            sonido.Sonar();
        } catch (UnsupportedAudioFileException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (LineUnavailableException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void detener() {
        sonido.detener();
    }
 
    public void pintarmapa(Graphics2D g){

        g.clearRect(0, 200, 800, 600);
        
        for (int i = 0; i < zisebloque; i++) {
            g.drawImage(bloques.get(i).getBloque(), bloques.get(i).x, bloques.get(i).y, bloques.get(i).width, bloques.get(i).height, null);
            g.drawRect(bloques.get(i).x, bloques.get(i).y, bloques.get(i).width, bloques.get(i).height);
        }
        
        for (int i = 0; i < ziseescalera; i++) {
            g.drawImage(escaleras.get(i).escaleras.next(), escaleras.get(i).x, escaleras.get(i).y, escaleras.get(i).width, escaleras.get(i).height, null);
            g.drawRect(escaleras.get(i).x, escaleras.get(i).y, escaleras.get(i).width, escaleras.get(i).height);
        }

    }
    
    @Override
    public void pintar(Graphics2D g){
       
        g.drawImage(fondo,0,0,800,565,null);
        pintarmapa(g);
        p.setDireccion(5);
        p.pintar(g);
        
    }
    
    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.VK_ENTER){
            if(actual<7)
            Ventana.actualizar(++actual);
        }
    }
    
    public void llenar(String[] temp, int posy){

        for (int i = 0; i < temp.length; i++) {
            
            if(temp[i].contains("2")){
                bloques.add(new bloque(40*i,40*posy,40,40));
                zisebloque++;
            }
            if(temp[i].contains("4")){
                escaleras.add(new escalera(40*i,40*posy,40,40));
                ziseescalera++;
                
            }
            if(temp[i].contains("0")){
                vacios.add(new vacio(40*i,40*posy,40,40));
                zisevacio++;
            }
            if(temp[i].contains("p")){
                p = new personaje(40*i,40*posy,40,40);
            }
        }
        
    }
    
    @Override
    public void leer(){
        
        String temp;
        String[] temp_read;
        int posy=0;
        
        try{
            FileReader fin = new FileReader(myFile);
            BufferedReader myread = new BufferedReader(fin);

            temp = myread.readLine();
            
            do{
                temp_read = temp.split(";");
                llenar(temp_read, posy);
                posy++;
            }while((temp = myread.readLine())!=null);

            myread.close();
            fin.close();

        }catch(Exception ex){ex.printStackTrace();}
    }
         
}
