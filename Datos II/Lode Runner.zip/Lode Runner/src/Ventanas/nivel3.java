
package Ventanas;

import Clases.sonido;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;

public class nivel3 extends escenarios{
    
    public Image nivel3 = new ImageIcon(getClass().getResource("/Imagenes/nivel3.png")).getImage();
    public sonido sonido;

    public nivel3() {
        sonido = new sonido("Start",0);
    }
    
    @Override
    public void sonar(){
        try {
            sonido.Sonar();
        } catch (UnsupportedAudioFileException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (LineUnavailableException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Image getNivel3() {
        return nivel3;
    }

    @Override
    public void detener() {
        sonido.detener();
    }
    
    @Override
    public void pintar(Graphics2D g) {
        g.drawImage(nivel3, 0, 0, null);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.VK_ENTER){
            Ventana.actualizar(3);
        }
    }
    
}
