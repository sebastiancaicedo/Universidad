
package Ventanas;

import Clases.*;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class mapa2 extends  escenarios{
    
    File myFile = new File("src/escenarios/mapa2.txt");
    //File myFile = new File("E:\\Uninorte\\Sistema\\Estructuras de Datos 2\\Lode Runner\\src\\escenarios\\mapa2.txt");

    ArrayList<bloquefalso> bloquesfalso = new ArrayList<bloquefalso>();
    int zisebloquefalso;
    ArrayList<mina> minas = new ArrayList<mina>();
    int zisemina, restantes;
    ArrayList<barra> barras = new ArrayList<barra>();
    int zisebarra;
    ArrayList<bloquefijo> bloquesfijo = new ArrayList<bloquefijo>();
    int zisebloquefijo;
    ArrayList<bloque> bloques = new ArrayList<bloque>();
    int zisebloque;
    ArrayList<escalera> escaleras = new ArrayList<escalera>();
    int ziseescalera;
    ArrayList<vacio> vacios = new ArrayList<vacio>();
    int zisevacio;
    ArrayList<enemigo> enemigos = new ArrayList<enemigo>();
    int ziseenemigo;
    personaje p; 
    public sonido sonido;
    
    @Override
    public void sonar(){
        try {
            sonido.Sonar();
        } catch (UnsupportedAudioFileException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (LineUnavailableException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void detener() {
        sonido.detener();
    }
    
    public mapa2(){
        sonido = new sonido("Theme",0);
    }
    Rectangle pantalla = new Rectangle(140,0,500,600);
    
    public void trasladar(Graphics2D g, int s){
        
        for (int i = 0; i < ziseenemigo; i++) {
            enemigos.get(i).x+=10*s;
        }
        
        for (int i = 0; i < zisemina; i++) {
            minas.get(i).x+=10*s;
        }
        
        for (int i = 0; i < zisebarra; i++) {
            barras.get(i).x+=10*s;
        }
        
        for (int i = 0; i < zisebloquefijo; i++) {
            bloquesfijo.get(i).x+=10*s; 
        }
        
        for (int i = 0; i < zisebloquefalso; i++) {
            bloquesfalso.get(i).x+=10*s; 
        }
        
        for (int i = 0; i < zisebloque; i++) {
            bloques.get(i).x+=10*s; 
        }
        
        for (int i = 0; i < ziseescalera; i++) {
            escaleras.get(i).x+=10*s; 
        }
        
        for (int i = 0; i < zisevacio; i++) {
            vacios.get(i).x+=10*s; 
        }
    }
    
    
    public void pintarmapa(Graphics2D g){
        g.clearRect(0, 0, 800, 600);
        for (int i = 0; i < ziseenemigo; i++) {
            g.drawImage(enemigos.get(i).fall.next(), enemigos.get(i).x, enemigos.get(i).y, 40, 40, null);
        }
        
        for (int i = 0; i < zisemina; i++) {
            g.drawImage(minas.get(i).minass.next(), minas.get(i).x, minas.get(i).y, minas.get(i).width, minas.get(i).height, null);
            //g.drawRect(minas.get(i).x, minas.get(i).y, minas.get(i).width, minas.get(i).height);
        }
        
        for (int i = 0; i < zisebarra; i++) {
            g.drawImage(barras.get(i).getBarra(), barras.get(i).x, barras.get(i).y, barras.get(i).width, barras.get(i).height, null);
            //g.drawRect(barras.get(i).x, barras.get(i).y, barras.get(i).width, barras.get(i).height);
        }
        
        for (int i = 0; i < zisebloquefijo; i++) {
            g.drawImage(bloquesfijo.get(i).getBloquefijo(), bloquesfijo.get(i).x, bloquesfijo.get(i).y, bloquesfijo.get(i).width, bloquesfijo.get(i).height, null);
            //g.drawRect(bloquesfijo.get(i).x, bloquesfijo.get(i).y, bloquesfijo.get(i).width, bloquesfijo.get(i).height);
        }
        
        for (int i = 0; i < zisebloque; i++) {
            if(bloques.get(i).visible)
            g.drawImage(bloques.get(i).getBloque(), bloques.get(i).x, bloques.get(i).y, bloques.get(i).width, bloques.get(i).height, null);
            //g.drawRect(bloques.get(i).x, bloques.get(i).y, bloques.get(i).width, bloques.get(i).height);
        }
        
        for (int i = 0; i < ziseescalera; i++) {
            g.drawImage(escaleras.get(i).escaleras.next(), escaleras.get(i).x, escaleras.get(i).y, escaleras.get(i).width, escaleras.get(i).height, null);
            //g.drawRect(escaleras.get(i).x, escaleras.get(i).y, escaleras.get(i).width, escaleras.get(i).height);
        }
        
        for (int i = 0; i < zisebloquefalso; i++) {
            g.drawImage(bloquesfalso.get(i).getBloquefalso(), bloquesfalso.get(i).x, bloquesfalso.get(i).y, 40, 40, null);
            //g.drawRect(bloquesfalso.get(i).x, bloquesfalso.get(i).y, 40, 40);
        }
        
        for (int i = 0; i < zisevacio; i++) {
            //g.drawRect(vacios.get(i).x, vacios.get(i).y, vacios.get(i).width, vacios.get(i).height);
        }
    }
    
    @Override
    public void pintar(Graphics2D g){
        
        pintarmapa(g);
        
        for (int i = 0; i < ziseenemigo; i++) {
            if(enemigos.get(i).intersects(p)){
                for (int j = 0; j < 12; j++) {
                    g.drawImage(p.dead.next(), p.x, p.y, 40, 40, null);
                }
                Ventana.actualizar(5);
                Ventana.llenar();
            }
        }
        
        /*g.drawRect(pantalla.x, pantalla.y, pantalla.width, pantalla.height);
        g.drawRect(p.x,p.y,1,40);
        g.drawRect(p.x,p.y,40,1);
        g.drawRect(p.x+40,p.y,1,40);
        g.drawRect(p.x,p.y+40,40,1);*/
        
                    
        if(restantes>0){            
        switch(p.getDireccion()){
            case 0:
                if(p.getCaida()){
                    p.caida();
                    for (int i = 0; i < zisebloquefijo; i++) {
                        if(bloquesfijo.get(i).intersects(p.d)){
                            p.setCaida(false);
                        }
                    }
        
                    for (int i = 0; i < zisebloque; i++) {
                        if(bloques.get(i).intersects(p.d)){
                            p.setCaida(false);
                        }
                    }
                    
                    
                }
                
                break;
            case 1:
                if(pantalla.intersects(p.r)){
                    comprobar1(g);
                }else{
                    comprobar1(g);
                    trasladar(g,-1);
                    p.setCaminar(false);
                    p.setEscalar(false);
                    p.setTrepar(false);
                }
                
                break;
            case 2:
                if(pantalla.intersects(p.l.x-10,p.l.y,p.l.width,p.l.height)){
                    comprobar2(g);
                }else{
                    comprobar2(g);
                    trasladar(g,1);
                    p.setCaminar(false);
                    p.setEscalar(false);
                    p.setTrepar(false);
                }
                
                break;
            case 3:

                comprobar3();
                break;
            case 4:

                comprobar4();
                break;
                
            case 6:
                for (int i = 0; i < zisebloque; i++) {
                    if(bloques.get(i).intersects(p.d)){
                        g.drawImage(bloques.get(i+1).bloquess.next(), bloques.get(i+1).x, bloques.get(i+1).y, 40, 40, null);
                        bloques.get(i+1).setVisible(false);
                        i=zisebloque;
                    }
                }
                break;
            case 7:
                for (int i = 0; i < zisebloque; i++) {
                    if(bloques.get(i).intersects(p.d)){
                        g.drawImage(bloques.get(i-1).bloquess.next(), bloques.get(i-1).x, bloques.get(i-1).y, 40, 40, null);
                        bloques.get(i-1).setVisible(false);
                        i=zisebloque;
                    }
                }
                break;
        }
        
        p.pintar(g);
        }else{
            ganar.actual=5;
            Ventana.actualizar(7);
        }
    }
    
    public void comprobar1(Graphics2D g){
        
        p.setCaminar(true);

        for (int i = 0; i < zisemina; i++) {
             if(p.intersects(minas.get(i))){
                minas.get(i).translate(1000, 1000);
                restantes--;
             }
        }
        
        for (int i = 0; i < zisebloquefijo; i++) {
            if(bloquesfijo.get(i).intersects(p.r.x-10,p.r.y,p.r.width,p.r.height) && !pantalla.intersects(p.r)){
                p.setCaminar(false);
                trasladar(g,1);
           }
        }
        
        for (int i = 0; i < zisebloquefijo; i++) {
            if(bloquesfijo.get(i).intersects(p.r)){
                p.setCaminar(false);
           }
        }
        
        for (int i = 0; i < zisebloque; i++) {
            if(bloques.get(i).intersects(p.r.x-10,p.r.y,p.r.width,p.r.height) && bloques.get(i).visible && !pantalla.intersects(p.r)){
                p.setCaminar(false);
                trasladar(g,1);
            }
        }
        
        for (int i = 0; i < zisebloque; i++) {
            if(bloques.get(i).intersects(p.r) && bloques.get(i).visible){
                p.setCaminar(false);
            }
        }
        
        for (int i = 0; i < zisebarra; i++) {
            if(barras.get(i).intersects(p.u)){
                p.setCaminar(false);
                p.setTrepar(true);
                p.setDireccion(8);
            }
        }
        
        for (int i = 0; i < zisevacio; i++) {
            if(vacios.get(i).intersects(p.d)){
                p.setCaida(true);
                p.setCaminar(false);
                p.vx=0;
            }
        }
        
    }

    public void comprobar2(Graphics2D g){
        
        p.setCaminar(true);
        
        for (int i = 0; i < zisemina; i++) {
             if(p.intersects(minas.get(i))){
                minas.get(i).translate(1000, 1000);
                restantes--;
             }
        }
        
        for (int i = 0; i < zisebloquefijo; i++) {
            if(bloquesfijo.get(i).intersects(p.l.x-10,p.l.y,p.l.width,p.l.height) && !pantalla.intersects(p.l.x-10,p.l.y,p.l.width,p.l.height)){
                p.setCaminar(false);
                trasladar(g,-1);
            }
        }
        
        for (int i = 0; i < zisebloquefijo; i++) {
            if(bloquesfijo.get(i).intersects(p.l.x-10,p.l.y,p.l.width,p.l.height)){
                p.setCaminar(false);
            }
        }
        
        for (int i = 0; i < zisebloque; i++) {
            if(bloques.get(i).intersects(p.l.x-10,p.l.y,p.l.width,p.l.height) && bloques.get(i).visible && !pantalla.intersects(p.l.x-10,p.l.y,p.l.width,p.l.height)){
                p.setCaminar(false);
                trasladar(g,1);
            }
        }
        
        for (int i = 0; i < zisebloque; i++) {
            if(bloques.get(i).intersects(p.l.x-10,p.l.y,p.l.width,p.l.height) && bloques.get(i).visible){
                p.setCaminar(false);
            }
        }
        
        for (int i = 0; i < zisebarra; i++) {
            if(barras.get(i).intersects(p.u)){
                p.setCaminar(false);
                p.setTrepar(true);
                p.setDireccion(9);
            }
        }
        
        for (int i = 0; i < zisevacio; i++) {
            if(vacios.get(i).intersects(p.d)){
                p.setCaida(true);
                p.setCaminar(false);
                p.vx=0;
            }
        }
    }
    
    public void comprobar3(){
        
        p.setCaminar(true);
        
        for (int i = 0; i < zisemina; i++) {
             if(p.intersects(minas.get(i))){
                minas.get(i).translate(1000, 1000);
                restantes--;
             }
        }
        
        for (int i = 0; i < zisebloquefijo; i++) {
            if(bloquesfijo.get(i).intersects(p.u.x,p.u.y-10,p.u.width,p.u.height)){
                p.setCaminar(false);
            }
        }
        
        for (int i = 0; i < zisebloque; i++) {
            if(bloques.get(i).intersects(p.u.x,p.u.y-10,p.u.width,p.u.height) ){
                p.setCaminar(false);
            }
        }
        
        for (int i = 0; i < zisevacio; i++) {
            if(vacios.get(i).intersects(p.u.x,p.u.y-10,p.u.width,p.u.height)){
                p.setEscalar(false);
                p.setCaminar(false);
            }
        }
        
        for (int i = 0; i < ziseescalera; i++) {
            if(escaleras.get(i).intersects(p.u.x,p.u.y-10,p.u.width,p.u.height) || escaleras.get(i).intersects(p)){
                p.setEscalar(true);
                p.setCaminar(true);
            }
        }
        
    }
    
    public void comprobar4(){
    
        p.setCaminar(true);
        
        for (int i = 0; i < zisemina; i++) {
             if(p.intersects(minas.get(i))){
                minas.get(i).translate(1000, 1000);
                restantes--;
             }
        }
        
        for (int i = 0; i < zisebloquefijo; i++) {
            if(bloquesfijo.get(i).intersects(p.d)){
                p.setCaminar(false);
            }
        }
        
        for (int i = 0; i < zisebloque; i++) {
            if(bloques.get(i).intersects(p.d) && bloques.get(i).visible){
                p.setCaminar(false);
            }
        }
        
        for (int i = 0; i < zisevacio; i++) {
            if(vacios.get(i).intersects(p.d)){
                p.setEscalar(false);
                p.setCaminar(false);
            }
        }
        
        for (int i = 0; i < ziseescalera; i++) {
            if(escaleras.get(i).intersects(p.d)){
                p.setEscalar(true);
                p.setCaminar(true);
            }
        }
        
        
        
    }
    
    @Override
    public void keyPressed(KeyEvent e) {
        switch(e.getKeyCode()){
            case KeyEvent.VK_RIGHT:
                if(p.getDireccion()==0)
                    p.setDireccion(1);
                break;
            case KeyEvent.VK_LEFT:
                if(p.getDireccion()==0)
                    if(!p.getCaida())
                    p.setDireccion(2);
                    p.setCaminar(true);
                break;
            case KeyEvent.VK_UP:
                if(p.getDireccion()==0)
                    if(!p.getCaida())
                    p.setDireccion(3);
                    p.setCaminar(true);
                break;
            case KeyEvent.VK_DOWN:
                if(p.getDireccion()==0)
                    if(!p.getCaida())
                    p.setDireccion(4);
                    p.setCaminar(true);
                break;
            case KeyEvent.VK_Z:
                if(p.getDireccion()==0)
                    if(!p.getCaida())
                    p.setDireccion(7);
                    p.setCaminar(true);
                break;
            case KeyEvent.VK_X:
                if(p.getDireccion()==0)
                    if(!p.getCaida())
                    p.setDireccion(6);
                    p.setCaminar(true);
                break;
                }
    }

    @Override
    public void keyReleased(KeyEvent e) {
       p.detenido();
    }

    public void llenar(String[] temp, int posy){
    
        for (int i = 0; i < temp.length; i++) {
            
            if(temp[i].contains("e")){
                enemigos.add(new enemigo(40*i,40*posy,40,40));
                ziseenemigo++;
            }
            if(temp[i].contains("p")){
                p = new personaje(40*i,40*posy,40,40);
            }
            if(temp[i].contains("1")){
                barras.add(new barra(40*i,40*posy,40,40));
                zisebarra++;
            }
            if(temp[i].contains("2")){
                bloques.add(new bloque(40*i,40*posy,40,40));
                zisebloque++;
            }
            if(temp[i].contains("3")){
                bloquesfijo.add(new bloquefijo(40*i,40*posy,40,40));
                zisebloquefijo++;
            }
            if(temp[i].contains("4")){
                escaleras.add(new escalera(40*i,40*posy,40,40));
                ziseescalera++;
            }
            if(temp[i].contains("0")){
                vacios.add(new vacio(40*i,40*posy,40,40));
                zisevacio++;
            }
            if(temp[i].contains("5")){
                bloquesfalso.add(new bloquefalso(40*i,40*posy));
                zisebloquefalso++;
            }
            if(temp[i].contains("m")){
                minas.add(new mina(40*i,40*posy,40,40));
                zisemina++;  
                restantes++;
            }
            
        }
    }
    
    @Override
    public void leer(){
        
        String temp;
        String[] temp_read;
        int posy=0;
        
        try{
            FileReader fin = new FileReader(myFile);
            BufferedReader myread = new BufferedReader(fin);

            temp = myread.readLine();
            
            do{
                temp_read = temp.split(";");
                llenar(temp_read, posy);
                posy++;
            }while((temp = myread.readLine())!=null);

            myread.close();
            fin.close();

        }catch(Exception ex){ex.printStackTrace();}
    }
    
}
