
package Ventanas;

import Clases.sonido;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;

public class fondo extends escenarios{
    
    public Image fondo = new ImageIcon(getClass().getResource("/Imagenes/fondo.png")).getImage();
    public Image punto = new ImageIcon(getClass().getResource("/Imagenes/punto.png")).getImage();
    int tiempo=0;
    public sonido sonido;
    
    public Image getFondo() {
        return fondo;
    }

    public Image getPunto() {
        return punto;
    }
    
    public fondo(){
        sonido = new sonido("Title",0);
    }
    
    @Override
    public void pintar(Graphics2D g){
        
        if(tiempo<10){
            g.drawImage(fondo,0,0,800,565,null);
        }
        
        tiempo++;
        
        if(tiempo%10==0){
           g.drawImage(punto,256,408,null);
        }
        
        if(tiempo%20==0){
           g.clearRect(256, 408, 16, 17);
        }
        
    }

    @Override
    public void sonar(){
        try {
            sonido.Sonar();
        } catch (UnsupportedAudioFileException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (LineUnavailableException ex) {
            Logger.getLogger(fondo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void detener() {
        sonido.detener();
    }
    
    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.VK_ENTER){
            Ventana.actualizar(4);
        }
    }
    
    
    
    
}
