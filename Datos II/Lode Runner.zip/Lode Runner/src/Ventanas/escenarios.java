
package Ventanas;

import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

public class escenarios {

    
    public void trasladar(){
    }

    public void leer(){
    }
    
    public void sonar(){
    }
    
    public void detener(){
    }
    
    public void pintar(Graphics2D g){  
    }
    
    public void keyPressed(KeyEvent e) {
    }

    public void keyReleased(KeyEvent e) {
    }

    public void keyTyped(KeyEvent e) {
    }
    
}
