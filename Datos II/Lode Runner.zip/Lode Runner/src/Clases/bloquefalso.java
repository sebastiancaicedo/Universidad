
package Clases;

import java.awt.Image;
import javax.swing.ImageIcon;

public class bloquefalso {
    
    Image bloquefalso = new ImageIcon(getClass().getResource("/Imagenes/bloque.png")).getImage();
    public int x, y;
    
    public bloquefalso(int x, int y) {
        this.x=x;
        this.y=y;
    }

    public Image getBloquefalso() {
        return bloquefalso;
    }
    
}
