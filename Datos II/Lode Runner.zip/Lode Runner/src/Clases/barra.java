
package Clases;

import java.awt.Image;
import java.awt.Rectangle;
import javax.swing.ImageIcon;

public class barra extends Rectangle{
    
    Image barra = new ImageIcon(getClass().getResource("/Imagenes/barra.png")).getImage();
    
    public barra(int x, int y, int w, int h){
        super(x,y,w,h);
    }

    public Image getBarra() {
        return barra;
    }
}
