
package Clases;

import java.awt.Image;
import java.util.ArrayList;
import javax.swing.ImageIcon;

public class Direcciones {
        
    ArrayList<ImageIcon> imagenes;
    private int size;
    private int actual;
    Image im;
    
    public Direcciones(String[] dir){
        imagenes = new ArrayList<ImageIcon>();
        for (String string : dir) {
            imagenes.add(new ImageIcon(string));            
        }
        size = dir.length;
        actual = -1;
    }
    
    public Image next(){
        return imagenes.get(++actual%size).getImage();
    }
}
