
package Clases;
import java.awt.Rectangle;

public class vacio extends Rectangle{

    public vacio(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

}
