
package Clases;

import java.awt.Image;
import java.awt.Rectangle;
import javax.swing.ImageIcon;

public class bloquefijo extends Rectangle{
    
    Image bloquefijo = new ImageIcon(getClass().getResource("/Imagenes/bloquefijo.png")).getImage();

    public bloquefijo(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    public Image getBloquefijo() {
        return bloquefijo;
    }

}
