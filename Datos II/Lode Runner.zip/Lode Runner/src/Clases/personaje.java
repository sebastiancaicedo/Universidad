
package Clases;

import java.awt.Graphics2D;
import java.awt.Rectangle;

public class personaje extends Rectangle{

    String arriba[]={"src\\Imagenes\\pu1.png","src\\Imagenes\\pu1.png","src\\Imagenes\\pu2.png","src\\Imagenes\\pu2.png"};
    String izquierda[]={"src\\Imagenes\\pl1.png","src\\Imagenes\\pl2.png","src\\Imagenes\\pl3.png","src\\Imagenes\\pl4.png"};
    String derecha[]={"src\\Imagenes\\pr1.png","src\\Imagenes\\pr2.png","src\\Imagenes\\pr3.png","src\\Imagenes\\pr4.png"};
    String quieto[]={"src\\Imagenes\\pq1.png","src\\Imagenes\\pq1.png","src\\Imagenes\\pq1.png","src\\Imagenes\\pq1.png","src\\Imagenes\\pq2.png","src\\Imagenes\\pq2.png","src\\Imagenes\\pq2.png","src\\Imagenes\\pq2.png"};
    String eizquierda[]={"src\\Imagenes\\el1.png","src\\Imagenes\\el2.png","src\\Imagenes\\el3.png"};
    String ederecha[]={"src\\Imagenes\\er1.png","src\\Imagenes\\er2.png","src\\Imagenes\\er3.png"};
    String caidaa[]={"src\\Imagenes\\c1.png","src\\Imagenes\\c2.png"};
    String ganaste[]={"src\\Imagenes\\g1.png","src\\Imagenes\\g1.png","src\\Imagenes\\g2.png","src\\Imagenes\\g2.png","src\\Imagenes\\g3.png","src\\Imagenes\\g3.png","src\\Imagenes\\g4.png","src\\Imagenes\\g4.png"};
    String ataque1[]={"src\\Imagenes\\a1.png","src\\Imagenes\\a1.png"};
    String ataque2[]={"src\\Imagenes\\a2.png","src\\Imagenes\\a2.png"};
    String muriendo[]={"src\\Imagenes\\d1.png","src\\Imagenes\\d1.png"
            ,"src\\Imagenes\\d2.png","src\\Imagenes\\d2.png"
            ,"src\\Imagenes\\d3.png","src\\Imagenes\\d3.png"
            ,"src\\Imagenes\\d4.png","src\\Imagenes\\d4.png"
            ,"src\\Imagenes\\d5.png","src\\Imagenes\\d5.png"
            ,"src\\Imagenes\\d6.png","src\\Imagenes\\d6.png"};
    
    public Direcciones dead = new Direcciones(muriendo);
    public Direcciones atack1 = new Direcciones(ataque1);
    public Direcciones atack2 = new Direcciones(ataque2);
    public Direcciones win = new Direcciones(ganaste);
    public Direcciones up = new Direcciones(arriba);
    public Direcciones right = new Direcciones(derecha);
    public Direcciones left = new Direcciones(izquierda);
    public Direcciones still = new Direcciones(quieto);
    public Direcciones eright = new Direcciones(ederecha);
    public Direcciones eleft = new Direcciones(eizquierda);
    public Direcciones fall = new Direcciones(caidaa);
    
    boolean trepar=false;
    boolean escalar=false;
    boolean caminar=true;
    boolean caida=false;
    boolean muerte=false;
    
    int direccion=0;
    
    public int vx=0,vy=0;
    
    public Rectangle u;
    public Rectangle d;
    public Rectangle r;
    public Rectangle l;
    
    public personaje(int x, int y){
        super(x,y);
    }
    
    public personaje(int x, int y, int width, int height) {
        super(x, y, width, height);
        this.l = new Rectangle(x,y,1,40);
        this.u = new Rectangle(x,y,40,1);
        this.r = new Rectangle(x+40,y,1,40);
        this.d = new Rectangle(x,y+40,40,1);
        
    }

    
    
    public boolean getCaida() {
        return caida;
    }

    public void setCaida(boolean caida) {
        this.caida = caida;
    }

    public boolean getCaminar() {
        return caminar;
    }

    public void setCaminar(boolean caminar) {
        this.caminar = caminar;
    }

    public boolean getEscalar() {
        return escalar;
    }

    public void setEscalar(boolean escalar) {
        this.escalar = escalar;
    }

    public boolean getTrepar() {
        return trepar;
    }

    public void setTrepar(boolean trepar) {
        this.trepar = trepar;
    }

    public int getDireccion() {
        return direccion;
    }

    public void setDireccion(int direccion) {
        this.direccion = direccion;
    }

    public void pintar(Graphics2D g){
        switch(getDireccion()){
            case 0:
                if(!caida){
                    g.drawImage(still.next(), x, y, 40, 40, null);
                }else{
                    g.drawImage(fall.next(), x, y, 40, 40, null);
                }
                break;
            case 1:
                g.drawImage(right.next(), x, y, 40, 40, null);
                break;
            case 2:
                g.drawImage(left.next(), x, y, 40, 40, null);
                break;
            case 3:
                g.drawImage(up.next(), x, y, 40, 40, null);
                break;
            case 4:
                g.drawImage(up.next(), x, y, 40, 40, null);
                break;
            case 5:
                g.drawImage(win.next(), x, y, 40, 40, null);
                break;
            case 6:
                g.drawImage(atack1.next(), x, y, 40, 40, null);
                break;
            case 7:
                g.drawImage(atack2.next(), x, y, 40, 40, null);
                break;
            case 8:
                g.drawImage(eright.next(), x, y, 40, 40, null);
                direccion=1;
                break;
            case 9:
                g.drawImage(eleft.next(), x, y, 40, 40, null);
                direccion=2;
                break;
        }

        mover();
    }
    
    public void mover(){
        
        
        
        switch(direccion){
            case 1:
                if(caminar && !caida){
                    vx=10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else if(trepar){
                    vx=10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else if(caida){
                    vx=0;
                }else{
                    vx=0;
                }
                break;
            case 2:
                if(caminar){
                    vx=-10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else if(trepar){
                    vx=-10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else if(caida){
                    vx=0;
                }else{
                    vx=0;
                }
                break;
            case 3:
                if(caminar){
                    vy=-10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else if(escalar){
                    if(caminar){
                        vy=-10;
                        super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                    }else{
                        vy=0;
                    }
                }else if(caida){
                    vy=0;
                }else{
                    vy=0;
                }
                break;
            case 4:
                if(caminar){
                    vy=10;
                    super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                }else if(escalar){
                    if(caminar){
                        vy=10;
                        super.x+=vx;
                    super.y+=vy;
                    u.x+=vx;
                    u.y+=vy;
                    l.x+=vx;
                    l.y+=vy;
                    r.x+=vx;
                    r.y+=vy;
                    d.x+=vx;
                    d.y+=vy;
                    }else{
                        vy=0;
                    }
                }else if(caida){
                    vy=0;
                }else{
                    vy=0;
                }
                break;
        }

        
    }
    
    public void caida(){
        super.x+=vx;
        super.y+=10;
        u.x+=vx;
        u.y+=10;
        l.x+=vx;
        l.y+=10;
        r.x+=vx;
        r.y+=10;
        d.x+=vx;
        d.y+=10;
    }  
    
    public void detenido() {
        if (!muerte) {
            vx=0;
            vy=0;
            direccion=0;
            caminar = false;
        }
    }
    
}
