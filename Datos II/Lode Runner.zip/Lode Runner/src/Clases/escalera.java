
package Clases;

import java.awt.Rectangle;

public class escalera extends Rectangle{

    String escalerass[]={"src\\Imagenes\\escalera1.png","src\\Imagenes\\escalera2.png","src\\Imagenes\\escalera3.png"};
    public Direcciones escaleras = new Direcciones(escalerass);
    
    public escalera(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

}
