package Clases;


import java.io.File;
import java.io.IOException;
import javax.sound.sampled.*;


public class sonido {
    
   Clip ol;
   String dir;
   int times;

    public sonido(String dir, int times) {
        this.dir = "Sonidos\\"+dir+".wav";
        this.times = times;
    }
   
   public void Sonar() throws UnsupportedAudioFileException, IOException, LineUnavailableException{
       File sf=new File(dir); 
       AudioFileFormat aff; 
       AudioInputStream ais; 
       aff=AudioSystem.getAudioFileFormat(sf); 
       ais=AudioSystem.getAudioInputStream(sf); 
       AudioFormat af=aff.getFormat(); 
       DataLine.Info info = new DataLine.Info( 
               Clip.class, 
               ais.getFormat(), 
               ((int) ais.getFrameLength() * 
               af.getFrameSize())); 
       ol = (Clip) AudioSystem.getLine(info); 
       ol.open(ais); 
        ol.loop(times);
    }
    public void detener() {
        if (ol != null) {
            ol.stop();
            ol.close();
        }

    }
}
