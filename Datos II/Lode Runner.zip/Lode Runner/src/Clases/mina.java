
package Clases;

import java.awt.Rectangle;

public class mina extends Rectangle{

    String mina[]={"src\\Imagenes\\mina1.png","src\\Imagenes\\mina1.png"
            ,"src\\Imagenes\\mina2.png","src\\Imagenes\\mina2.png"
            ,"src\\Imagenes\\mina3.png","src\\Imagenes\\mina3.png"};
            
    public Direcciones minass = new Direcciones(mina);
    
    public boolean visible=true;
    
    public mina(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }
    
}
