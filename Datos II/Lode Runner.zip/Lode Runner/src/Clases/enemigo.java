
package Clases;

import java.awt.Rectangle;

public class enemigo extends Rectangle{

    String arriba[]={"src\\Imagenes\\eu1.png","src\\Imagenes\\eu1.png","src\\Imagenes\\eu2.png","src\\Imagenes\\eu2.png"};
    String izquierda[]={"src\\Imagenes\\enl1.png","src\\Imagenes\\enl2.png","src\\Imagenes\\enl3.png"};
    String derecha[]={"src\\Imagenes\\enr1.png","src\\Imagenes\\enr2.png","src\\Imagenes\\enr3.png"};
    String eizquierda[]={"src\\Imagenes\\eel1.png","src\\Imagenes\\eel2.png"};
    String ederecha[]={"src\\Imagenes\\eer1.png","src\\Imagenes\\eer2.png"};
    String caidaa[]={"src\\Imagenes\\ec1.png","src\\Imagenes\\ec2.png"};
    
    public Direcciones up = new Direcciones(arriba);
    public Direcciones right = new Direcciones(derecha);
    public Direcciones left = new Direcciones(izquierda);
    public Direcciones eright = new Direcciones(ederecha);
    public Direcciones eleft = new Direcciones(eizquierda);
    public Direcciones fall = new Direcciones(caidaa);
    
    
    public enemigo(int x, int y, int width, int height) {
        super(x, y, width, height);
    }
    
    
}
