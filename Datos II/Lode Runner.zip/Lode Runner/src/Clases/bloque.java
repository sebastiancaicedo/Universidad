
package Clases;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import javax.swing.ImageIcon;

public class bloque extends Rectangle{
    
    Image bloque = new ImageIcon(getClass().getResource("/Imagenes/bloque.png")).getImage();

    String bloques[]={"src\\Imagenes\\f1.png","src\\Imagenes\\f1.png","src\\Imagenes\\f2.png"
            ,"src\\Imagenes\\f2.png","src\\Imagenes\\f3.png","src\\Imagenes\\f3.png","src\\Imagenes\\f4.png"
            ,"src\\Imagenes\\f4.png","src\\Imagenes\\f5.png","src\\Imagenes\\f5.png","src\\Imagenes\\f6.png"
            ,"src\\Imagenes\\f6.png","src\\Imagenes\\f7","src\\Imagenes\\f7.png","src\\Imagenes\\f8.png"
            ,"src\\Imagenes\\f8.png","src\\Imagenes\\f9.png","src\\Imagenes\\f9.png"};
            
    public Direcciones bloquess = new Direcciones(bloques);
    
    public boolean visible=true;
    
    public bloque(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public Image getBloque() {
        return bloque;
    }
        
}
