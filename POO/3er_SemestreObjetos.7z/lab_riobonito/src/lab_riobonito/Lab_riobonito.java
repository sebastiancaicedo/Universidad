/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_riobonito;

import java.io.*;
import java.io.IOException;
public class Lab_riobonito {
    
    public void escArch(){
        String saludo="Hola";
        try
        {
            //Crear un objeto File se encarga de crear o abrir acceso a un archivo que se especifica en su constructor
            File archivo=new File("texto.txt");
            
            //Crear objeto FileWriter que sera el que nos ayude a escribir sobre archivo
            BufferedWriter escribir= new BufferedWriter(new FileWriter(archivo,true));
          
           
            //Escribimos en el archivo con el metodo write
            escribir.write(saludo);
            escribir.newLine();
            
            

            //Cerramos la conexion
            escribir.close();
            }catch(IOException e)
            {
                System.out.println("Error al escribir");
            }
        
    }
    
    public void leeArch(String archivo){
        
        try
        {
            BufferedReader leer= new BufferedReader (new FileReader(archivo));
            String linea= "";
            while((linea= leer.readLine()) != null){
                //String[] vec= linea.split(";"); Esto es para dividir las lineas
                System.out.println(linea); //se muestran las lineas completas del archivo
            }
            
            leer.close();
        }catch(IOException e){}
    }

    public static void main(String[] args) {
        
            Lab_riobonito m= new Lab_riobonito();
            
            m.leeArch("texto.txt");
    }
}

