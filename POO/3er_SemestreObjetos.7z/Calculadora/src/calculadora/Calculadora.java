/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;
import java.io.BufferedReader;
import java.io.InputStreamReader;
/**
 *
 * @author sebastiancaicedo
 */
public class Calculadora {
    
    public void escMensaje(String men){
        System.out.println(men);
    }
    
    public void escMensaje2(String men){
        System.out.print(men);
    }
    
    public String leerMensaje(String men){
        String temp;
        
        BufferedReader bf = new BufferedReader(
                new InputStreamReader(System.in));
        
        escMensaje2(men);
        
        try {
            temp=bf.readLine();
        } catch (Exception ex) {ex.printStackTrace(); temp="";}
        
        return temp;
    }
    
    public int leerInt(String men){
        String temp = leerMensaje(men);
        int tempNum;
        
        try{
            tempNum = Integer.parseInt(temp);
        }catch(Exception ex){tempNum=0;}
      
        return tempNum;
    }
    
//    public double leerDoble(String men){
//        String temp= leerMensaje(men);
//        double tempNum;
//        
//        try{
//            tempNum= Double.parseDouble(temp);
//        }catch(Exception ex){ex.printStackTrace(); tempNum=0;}
//        return tempNum;
//    }
    
    public int sumaInt(int a, int b){
        return a+b;
    }
    
    public double sumaDouble(double a, double b){
        return a+b;
    }
    
    public int restaInt(int a, int b){
        return a-b;
    }
    
    public double restaDouble(double a, double b){
        return a-b;
    }
    
    public int multInt(int a, int b){
        return a*b;
    }
    
    public double multDouble(double a, double b){
        return a*b;
    }
    
    public int divInt(int a, int b){
        return a/b;
    }
    
    public double divDouble(double a, double b){
        return a/b;
    }
    
    public boolean validInt(String n1, String n2){
        boolean sw=true;
        if(sw==true){
            try{
                Integer.parseInt(n1);
                Integer.parseInt(n2);
            }catch(Exception ex){sw=false;};
        }
        return sw;
    }
    
    public boolean validDouble(String n1, String n2){
        boolean sw=true;
        if(sw==true){
            try{
                Double.parseDouble(n1);
                Double.parseDouble(n2);
            }catch(Exception ex){sw=false;};
        }
        return sw;
    }
            
    public void Menu(){
        int opcion;
        do{
            escMensaje("***********MENU**********");
            escMensaje("1.Suma");
            escMensaje("2.Resta");
            escMensaje("3.Multiplicación");
            escMensaje("4.División");
            escMensaje("5.Salir");
            escMensaje("*************************");
            do{
                opcion= leerInt("Ingrese la opcion: ");
                if(opcion<1 || opcion>5){
                    escMensaje("Opcion NO valida.");
                }
            }while(opcion <1 || opcion >5);
            if(opcion != 5){
 
            } 
            switch(opcion){
                case 1:
                    String num1s= leerMensaje("Ingrese el primer numero: ");
                    String num2s= leerMensaje("Ingrese el segundo numero: ");
                    if(validInt(num1s,num2s)== true){
                        escMensaje("El Resultado de la suma es: "+this.sumaInt(Integer.parseInt(num1s),Integer.parseInt(num2s)));
                    }
                    else
                    {
                        if(validDouble(num1s,num2s)==true){
                            
                            escMensaje("El resultado de la suma es: "+this.sumaDouble(Double.parseDouble(num1s), Double.parseDouble(num2s)));
                        }
                        else
                        {
                            escMensaje("Digitos No validos");
                        }
                    }
                    
                    break;
                case 2:
                    String num1r= leerMensaje("Ingrese el primer numero: ");
                    String num2r= leerMensaje("Ingrese el segundo numero: ");
                    if(validInt(num1r,num2r)==true){
                        escMensaje("EL resultado de la resta es: "+this.restaInt(Integer.parseInt(num1r),Integer.parseInt(num2r)));
                    }
                    else
                    {
                        if(validDouble(num1r,num2r)==true){
                            escMensaje("El resultado de la resta es: "+this.restaDouble(Double.parseDouble(num1r),Double.parseDouble(num2r)));
                        }
                        else
                        {
                            escMensaje("Digitos No validos");
                        }
                    }

                    break;
                case 3:
                    String num1m= leerMensaje("Ingrese el primer numero: ");
                    String num2m= leerMensaje("Ingrese el segundo numero: ");
                    if(validInt(num1m,num2m)==true){
                        escMensaje("El resultado de la multiplicaion es: "+this.multInt(Integer.parseInt(num1m), Integer.parseInt(num2m)));
                    }
                    else
                    {
                        if(validDouble(num1m,num2m)==true){
                            escMensaje("El resultado de la multiplicacion es: "+this.multDouble(Double.parseDouble(num1m), Double.parseDouble(num2m)));
                        }
                        else
                        {
                            escMensaje("Digitos no validos");
                        }
                    }

                    break;
                case 4:
                    String num1d= leerMensaje("Ingrese el primer numero: ");
                    String num2d= leerMensaje("Ingrese el segundo numero: ");
                    if(num2d.equals("0")==false){
                        if(validInt(num1d,num2d)==true){
                            escMensaje("El resultado de la división es: "+this.divInt(Integer.parseInt(num1d), Integer.parseInt(num2d)));
                        }
                        else
                        {
                            if(validDouble(num1d,num2d)==true){
                                escMensaje("El resultado de la division es: "+this.divDouble(Double.parseDouble(num1d), Double.parseDouble(num2d)));
                            }
                        }
                    }
                    else
                    {
                        escMensaje("No esta definidia por el denominador igual 0");
                    }
                    

                    break;
                case 5:
                    escMensaje("Gracias por usar este softwre");
                    break;
            }
        }while(opcion != 5);
    }
    
    public static void main(String[] args) {
        Calculadora c= new Calculadora();
        c.Menu();
        // TODO code application logic here
    }
}
