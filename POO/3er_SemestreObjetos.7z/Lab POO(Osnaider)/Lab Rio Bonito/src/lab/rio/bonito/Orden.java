/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.rio.bonito;
import java.io.File;
import java.io.FileWriter;
/**
 *
 * @author Osnaider
 */
public class Orden{
    public String tipo;
    public int cant;
    public int est; //1=confirmado, 2=pendiente, 3= cancelado
    public int ref;
    public String cliente;
    
  
       /* public void añadirArchivo(){
       String saludo= "hola mundo";
       try{
           File archivo=new File("orden.txt");
           FileWriter escribir=new FileWriter(archivo,true);
           escribir.write(saludo);
           escribir.close();
       }catch(Exception e){
       }
    
   }*/

    /*void crear() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }*/
   
    
    public class Nodo{
        protected int info;
        protected Nodo link;
        Nodo(){}
        Nodo(int info){
            this.info=info;
            this.link=null;
        }
    }
    
    
    public class Lista extends Nodo{
        Nodo PTR;
        Nodo Ult;
        
        Lista(){
            PTR=null;
            Ult=null;
        }
        
        public void agregar(Nodo p){
        if(Ult==null){
            PTR=p;
        }
        else{
            Ult.link=p;
        }
        }
        
         public boolean existeNodoCon(int info) {
             boolean verificar = false;
            Nodo p = PTR;
            while(p!=null){
                 if(p.info == info) verificar = true;
                    p = p.link;
                 }
            return verificar; //lo puse asi solo para compilar       
         }
   
   public void eliminaPrimero() {
       Nodo p = PTR;
       if(p!=null){
            p = p.link;
            PTR = p;       
        }
   }
   
   public void eliminaUltimo() {
     Nodo p = PTR;
     while(p!=null){
         if(p.link == Ult){
            p.link = null;
            Ult = p;
        }   
        p = p.link;
     }
  
   }
   

   
    
    }
}
