/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package labpoo;

import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/**
 *
 * @author sebastiancaicedo
 */
public class Turno {
    
    String num;
    String tipo;
    String carga;
    String porcen;
    String estado;
    
        private int asignarCodigo(ArrayList<String> List){
       
        int cod;
        if(List.size()==0){
            return cod=0;
        }
        else
        {
            String linea= List.get(List.size()-1);
            String[] vec= linea.split(";");
            cod= Integer.parseInt(vec[0]);
            return cod+1;
        }
    }
    
    
        public void buscOrdConfir(ArrayList<String> Listord,ArrayList<String> Listtur){
        
        String linea;
        for(int i=0;i<=Listord.size()-1;i++){
            linea= Listord.get(i);
            String[] vec= linea.split(";");
            if ("Lista".equals(vec[8])==false){
                if("Confirmada".equals(vec[1])==true){
                    linea= vec[0]+";"+vec[1]+";"+vec[2]+";"+vec[3]+";"+vec[4]+";"+vec[5]+";"+vec[6]+";"+vec[7]+";"+"Lista";
                    Listord.set(i, linea);
                    if("Crudo".equals(vec[2])==true){
                        if("Ligero".equals(vec[3])==true){
                                crearTurno(linea,"Ligero",Listtur,0);    
                        }
                        else
                            if("Pesado".equals(vec[3])==true){
                        
                                crearTurno(linea,"Pesado",Listtur,0);
                            
                            }
                    else
                                if("Extrapesado".equals(vec[3])==true){
                            
                                    crearTurno(linea,"Extrapesado",Listtur,0);
                                }
                    }
                    else
                        if("Derivados Refinados".equals(vec[2])==true){
                            if("GASOLINA".equals(vec[3])==true){
                                crearTurno(linea,"GASOLINA",Listtur,1);
                            }
                            else
                                if("DIESEL".equals(vec[3])==true){
                                    crearTurno(linea,"DIESEL",Listtur,1);
                                }
                            else
                                    if("OTROS".equals(vec[3])==true){
                                        crearTurno(linea,"OTROS",Listtur,1);
                                    }
                        }
                    else
                            if("Carga General".equals(vec[2])==true){
                                
                                crearTurnoCGeneral(linea,"General",Listtur);
                            }
                }
            }
            
        }
    }
    
    private void crearTurno(String orden,String tip, ArrayList<String> Listtur, int m){
        boolean sw=false;
        Turno t=new Turno();
        t.num=asignarCodigo(Listtur)+"";
        t.tipo=tip;
        String lineaturno;
        if(Listtur.isEmpty()==true){
            t.carga=orden.split(";")[4];
            t.porcen=calcPorcen(t.carga)+"";
            t.estado=asigEstadoTur(calcPorcen(t.carga));
            lineaturno=t.num+";"+t.tipo+";"+t.carga+";"+t.porcen+";"+t.estado+";"+orden.split(";")[0];
            Listtur.add(lineaturno); 
        }
        else
        {
            int i=0;
            while(i<= Listtur.size()-1 && sw==false){
                String turno= Listtur.get(i);
                String[] v= turno.split(";");
                if("Despachado".equals(v[4])==false){
                    if(orden.split(";")[3].equals(v[1])==true){
                        if(verifCabida(orden,Listtur,i)== true){
                            sw=true;
                            lineaturno= Listtur.get(i);
                            String[] vec= lineaturno.split(";");
                            t.carga=(Integer.parseInt(vec[2])+ Integer.parseInt(orden.split(";")[4]))+"";
                            vec[2]=t.carga;
                            t.porcen= calcPorcen(t.carga)+"";
                            vec[3]=t.porcen;
                            t.estado= asigEstadoTur(calcPorcen(t.carga));
                            vec[4]=t.estado;
                            String lineaaux=lineaturno;
                            String[] lineaauxvec= lineaaux.split(";");
                            lineaturno=vec[0]+";"+vec[1];
                            int k=2;
                            while(k <= lineaauxvec.length-1){
                                lineaturno=lineaturno+";"+vec[k];
                                k++;
                            }
                            lineaturno=lineaturno+","+orden.split(";")[0];
                            Listtur.set(i, lineaturno);
                        }
                    }
                }
                i++;
            }
            if(sw==false){
                if(m==0){
                    t.carga=orden.split(";")[4];
                }
                else
                    if(m==1){
                        t.carga=orden.split(";")[5];
                    }
                
                t.porcen=calcPorcen(t.carga)+"";
                t.estado=asigEstadoTur(calcPorcen(t.carga));
                lineaturno=t.num+";"+t.tipo+";"+t.carga+";"+t.porcen+";"+t.estado+";"+orden.split(";")[0];
                Listtur.add(lineaturno);
            }
        }
        
    }
    
    private void crearTurnoCGeneral(String orden,String tip, ArrayList<String> Listtur){
        boolean sw=false;
        Turno t=new Turno();
        t.num=asignarCodigo(Listtur)+"";
        t.tipo=tip;
        String lineaturno;
        if(Listtur.isEmpty()==true){
            t.carga=orden.split(";")[6]+"-"+orden.split(";")[5];
            t.porcen=calcPorcen(t.carga)+"";
            t.estado=asigEstadoTur(calcPorcen(t.carga));
            lineaturno=t.num+";"+t.tipo+";"+t.carga+";"+t.porcen+";"+t.estado+";"+orden.split(";")[0];
            Listtur.add(lineaturno); 
        }
        else
        {
            int i=0;
            while(i<= Listtur.size()-1 && sw==false){
                String turno= Listtur.get(i);
                String[] v= turno.split(";");
                if("Despachado".equals(v[4])==false){
                    //if(orden.split(";")[3].equals(v[1])==true){
                        if(verifCabidaCGeneral(orden,Listtur,i)== true){
                            sw=true;
                            lineaturno= Listtur.get(i);
                            String[] vec= lineaturno.split(";");
                            t.carga=(Integer.parseInt(vec[2].split("-")[0])+ Integer.parseInt(orden.split(";")[6]))+"-"+(Integer.parseInt(vec[2].split("-")[1])+ Integer.parseInt(orden.split(";")[5]+""));
                            vec[2]=t.carga;
                            t.porcen= calcPorcenCGeneral(t.carga)+"";
                            vec[3]=t.porcen;
                            t.estado= asigEstadoTur(calcPorcenCGeneral(t.carga));
                            vec[4]=t.estado;
                            String lineaaux=lineaturno;
                            String[] lineaauxvec= lineaaux.split(";");
                            lineaturno=vec[0]+";"+vec[1];
                            int k=2;
                            while(k <= lineaauxvec.length-1){
                                lineaturno=lineaturno+";"+vec[k];
                                k++;
                            }
                            lineaturno=lineaturno+","+orden.split(";")[0];
                            Listtur.set(i, lineaturno);
                        }
                    //}
                }
                i++;
            }
            if(sw==false){
                t.carga=orden.split(";")[6]+"-"+orden.split(";")[5];
                t.porcen=calcPorcenCGeneral(t.carga)+"";
                t.estado=asigEstadoTur(calcPorcenCGeneral(t.carga));
                lineaturno=t.num+";"+t.tipo+";"+t.carga+";"+t.porcen+";"+t.estado+";"+orden.split(";")[0];
                Listtur.add(lineaturno);
            }
        }
    }
    
    private double calcPorcen(String cantidad){
        
        double por;
        por= (Double.parseDouble(cantidad));
        return (por*100)/50000;
    }
    
    private String asigEstadoTur(double porcentaje){
        
        if(porcentaje<80){
            return "Pendiente";
        }
        else
        {
            return "Elegible para Despacho";
        }
    }
    
    private boolean verifCabida(String orden,ArrayList<String> List,int i){
        

            String[] vec=List.get(i).split(";");
            if(Integer.parseInt(orden.split(";")[4])+Integer.parseInt(vec[2])<=50000){
                return true;
            }
        return false;
    }
    
    private boolean verifCabidaCGeneral(String orden,ArrayList<String> List,int i){
        
        String[] vec= List.get(i).split(";");
        String[] v= vec[2].split("-");
        if(Integer.parseInt(orden.split(";")[6])+ Integer.parseInt(v[0])<= 100 && Integer.parseInt(orden.split(";")[5])+ Integer.parseInt(v[1])<=2000){
            return true;
        }
        return false;
    }
    
    private double calcPorcenCGeneral(String cant){
        
        double p= Double.parseDouble(cant.split("-")[0]);
        double a= (Double.parseDouble(cant.split("-")[1])*100)/2000;
        if(p>=a){
            return p;
        }
        else
        {
            return a;
        }
    }
    
    public void busqTurnoPorcen(String porcen,ArrayList<String> List,DefaultListModel model){
        
        for(int i=0;i<=List.size()-1;i++){
            if(Double.parseDouble(List.get(i).split(";")[3]) >= Double.parseDouble(porcen)){
                model.addElement("# Turno: "+List.get(i).split(";")[0]);
                model.addElement("Tipo: "+List.get(i).split(";")[1]);
                model.addElement("Carga total: "+List.get(i).split(";")[2]);
                model.addElement("% Carga usada :"+List.get(i).split(";")[3]);
                model.addElement("Estado: "+List.get(i).split(";")[4]);
                model.addElement("------------------------------------");
            }
        }
    }
    
    public void busqTurnoTipo(String tip,ArrayList<String> List,DefaultListModel model){
        
        for(int i=0;i<=List.size()-1;i++){
            if("Crudo".equals(tip)==true){
                if(List.get(i).split(";")[1].equals("Ligero")==true || List.get(i).split(";")[1].equals("Pesado")==true || List.get(i).split(";")[1].equals("Extrapesado")==true){
                    model.addElement("# Turno: "+List.get(i).split(";")[0]);
                    model.addElement("Tipo: "+List.get(i).split(";")[1]);
                    model.addElement("Carga total: "+List.get(i).split(";")[2]);
                    model.addElement("% Carga usada :"+List.get(i).split(";")[3]);
                    model.addElement("Estado: "+List.get(i).split(";")[4]);
                    model.addElement("------------------------------------");
                }
            }
                else
                    if("Derivados Refinados".equals(tip)== true){
                        if(List.get(i).split(";")[1].equals("GASOLINA")==true || List.get(i).split(";")[1].equals("DIESEL")==true || List.get(i).split(";")[1].equals("ORTOS DERIVADOS")==true){
                            model.addElement("# Turno: "+List.get(i).split(";")[0]);
                            model.addElement("Tipo: "+List.get(i).split(";")[1]);
                            model.addElement("Carga total: "+List.get(i).split(";")[2]);
                            model.addElement("% Carga usada :"+List.get(i).split(";")[3]);
                            model.addElement("Estado: "+List.get(i).split(";")[4]);
                            model.addElement("------------------------------------");
                        }
                    }
                else
                    {
                        if("Carga General".equals(tip)==true){
                            if(List.get(i).split(";")[1].equals("Ligero")==false && List.get(i).split(";")[1].equals("Pesado")==false && List.get(i).split(";")[1].equals("Extrapesado")==false && List.get(i).split(";")[1].equals("GASOLINA")==false && List.get(i).split(";")[1].equals("DIESEL")==false && List.get(i).split(";")[1].equals("ORTOS DERIVADOS")==false){
                                model.addElement("# Turno: "+List.get(i).split(";")[0]);
                                model.addElement("Tipo: "+List.get(i).split(";")[1]);
                                model.addElement("Carga total: "+List.get(i).split(";")[2]);
                                model.addElement("% Carga usada :"+List.get(i).split(";")[3]);
                                model.addElement("Estado: "+List.get(i).split(";")[4]);
                                model.addElement("------------------------------------");
                            }
                        }
                    }
                    
            }
        
    }
    
    public void busqTurnoOrden(String codord,ArrayList<String> List, DefaultListModel model){
        int i=0;boolean sw=false;
        while(i<=List.size()-1 && sw==false){
            String[] ord= List.get(i).split(";")[5].split(",");
            int j=0;
            while(j<= ord.length-1 && sw==false){
                if(codord.equals(ord[j])==true){
                    sw=true;
                    model.addElement("# Turno: "+List.get(i).split(";")[0]);
                    model.addElement("Tipo: "+List.get(i).split(";")[1]);
                    model.addElement("Carga total: "+List.get(i).split(";")[2]);
                    model.addElement("% Carga usada :"+List.get(i).split(";")[3]);
                    model.addElement("Estado: "+List.get(i).split(";")[4]);
                    model.addElement("------------------------------------");
                }
                j++;
            }
            i++;
        }
        if(sw==false){
            JOptionPane.showMessageDialog(null, "No hay turno con esa orden");
        }
    }
    
    public void busqTurnoEstado(String estado,ArrayList<String> List,DefaultListModel model){
        
        for(int i=0;i<=List.size()-1;i++){
            if(estado.equals(List.get(i).split(";")[4])==true){
                model.addElement("# Turno: "+List.get(i).split(";")[0]);
                model.addElement("Tipo: "+List.get(i).split(";")[1]);
                model.addElement("Carga total: "+List.get(i).split(";")[2]);
                model.addElement("% Carga usada :"+List.get(i).split(";")[3]);
                model.addElement("Estado: "+List.get(i).split(";")[4]);
                model.addElement("------------------------------------");
            }
        }
    }
    


}


