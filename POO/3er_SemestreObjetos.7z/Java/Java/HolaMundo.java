/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package holamundo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author pwightman
 */
public class HolaMundo {

    private String mensaje="Hola Mundo!";
    
    public void setMensaje(String men){
        mensaje = men;
    }
    
    public void escribirMensaje(){
       System.out.println(mensaje);
    }
    
    public void escribirMensaje2(String men){
       System.out.print(men);
    }
    
    public String leerMensaje(String mensaje){
    
        String temp;
        
        BufferedReader bf = new BufferedReader(
                new InputStreamReader(System.in));
        
        escribirMensaje2(mensaje);
        
        try {
            temp=bf.readLine();
        } catch (Exception ex) {ex.printStackTrace(); temp="";}
        
        return temp;
    }
    
    public int leerInt(String mensaje){
    
        String temp = leerMensaje(mensaje);
        int tempNum = 0;
        
        try{
            tempNum = Integer.parseInt(temp);
        }catch(Exception ex){ex.printStackTrace(); tempNum=0;}
        
        return tempNum;
    }

    public static void main(String[] args) {
        
        HolaMundo hm = new HolaMundo();
        String t;
        int year;
        
        hm.escribirMensaje();
        
        t=hm.leerMensaje("Escribe tu nombre: ");
        
        hm.setMensaje("Hola "+t+"!");
        
        hm.escribirMensaje();
        
        year = hm.leerInt("Ingrese año de nacimiento: ");
        
        if(2013-year >=18){
            hm.escribirMensaje2("Eres mayor de edad");
        }else{
            hm.escribirMensaje2("No eres mayor de edad");
        }
        
        hm.escribirMensaje2("\nGracias por usar este software!\n");
        
    }
}