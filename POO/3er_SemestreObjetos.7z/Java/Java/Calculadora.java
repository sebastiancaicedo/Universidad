/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author pwightman
 */
public class Calculadora {

    int[] array = new int[10];
    
    public double suma(double a, double b){
        return a+b;
    }
    
    public void escribirMensaje(String men){
       System.out.println(men);
    }
    
    public void escribirMensaje2(String men){
       System.out.print(men);
    }
    
    public String leerMensaje(String mensaje){
    
        String temp;
        
        BufferedReader bf = new BufferedReader(
                new InputStreamReader(System.in));
        
        escribirMensaje2(mensaje);
        
        try {
            temp=bf.readLine();
        } catch (Exception ex) {ex.printStackTrace(); temp="";}
        
        return temp;
    }
    
    public int leerInt(String mensaje){
    
        String temp = leerMensaje(mensaje);
        int tempNum = 0;
        
        try{
            tempNum = Integer.parseInt(temp);
        }catch(Exception ex){ex.printStackTrace(); tempNum=0;}
        
        return tempNum;
    }
    
    public double leerDouble(String mensaje){
    
        String temp = leerMensaje(mensaje);
        double tempNum = 0.0;
        
        try{
            tempNum = Double.parseDouble(temp);
        }catch(Exception ex){ex.printStackTrace(); tempNum=0;}
        
        return tempNum;
    }
    
    public void menu(){
        int opcion=0;
        do{
            escribirMensaje("");
            escribirMensaje("**************************");
            escribirMensaje("Super Calculadora V. 0.89");
            escribirMensaje("**************************");
            escribirMensaje("");
            escribirMensaje("1. Suma");
            escribirMensaje("2. Resta");
            escribirMensaje("3. Salir");
            escribirMensaje("");
            do{
                opcion = leerInt("Ingrese la opción: ");
                if(opcion<1 || opcion >3){
                    escribirMensaje("Opción inválida");
                }
            }while(opcion<1 || opcion >3);
            
            double a=0,b=0;
            
            switch(opcion){
                case 1:
                    a=0;
                    b=0;
                    escribirMensaje("");
                    a=this.leerDouble("Ingrese el primer valor: ");
                    escribirMensaje("");
                    b=this.leerDouble("Ingrese el segundo valor: ");
                    escribirMensaje("");
                    escribirMensaje("El resultado es: "+this.suma(a, b));
                break;
            
                case 3: 
                    escribirMensaje("Gracias por usar este software!");
                    break;
                    
                    
                default:
                    escribirMensaje("Opcion no implementada o incorrecta");
                    break;
                    
            }
            
        }while(opcion!=3);
        
        
    }
            
            
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Calculadora c = new Calculadora();
        
        c.menu();
        
    }
}