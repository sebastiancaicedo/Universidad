/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package labpoo;

import java.util.ArrayList;
import javax.swing.DefaultListModel;

/**
 *
 * @author sebastiancaicedo
 */
public class Orden {
    
    protected String tipo;
    protected String cantidad;
    protected String estado;
    protected String numRef;
    protected String cliente;
    
    
    protected int asignarCodigo(ArrayList<String> List){
       
        int cod;
        if(List.size()==0){
            return cod=0;
        }
        else
        {
            String linea= List.get(List.size()-1);
            String[] vec= linea.split(";");
            cod= Integer.parseInt(vec[0]);
            return cod+1;
        }
    }
    
    public boolean verifEstadoOrden(String cod,ArrayList<String> List){
        
        String linea;
        for(int i=0;i<=List.size()-1;i++){
            linea= List.get(i);
            String[] vec= linea.split(";");
            if(cod.equals(vec[0])==true){
                if("Pendiente".equals(vec[1])==true){
                    return true;
                }
                return false;
            }
        }
        
        return false;
    }
    
    public boolean verifExistOrden(String cod, ArrayList<String> List){
        
        String linea;int i=0;
        while(i<= List.size()-1){
            linea= List.get(i);
            String[] vec= linea.split(";");
            if(cod.equals(vec[0])==true){
                return true;
                
            }
            i++;
        }
        return false;
    }
    
    public void cambiarEstadoOrden(String cod, ArrayList<String> List){
        
        String linea="";
        int i=0;boolean sw=false;
        while( i <=(List.size()-1) && sw == false){
            linea= List.get(i);
            String[] vec= linea.split(";");
            if(cod.equals(vec[0])==true){
                vec[1]="Confirmada";
                linea=vec[0];
                int j=1;
                while(j < vec.length){
                    linea=linea+";"+vec[j];
                    j++;
                }
                sw=true;
                List.set(i, linea);
            }
            i++;
        }
        
    }
    

    
    public void cancelarOrden(String cod, ArrayList<String> List){
        
        String linea="";int i=0;boolean sw=false;
        while(i<= List.size()-1 && sw==false){
            linea= List.get(i);
            String[] vec= linea.split(";");
            if(cod.equals(vec[0])==true){
                List.remove(linea);
                sw=true;
            }
            i++;
        }
    }
    
    
    public void listarOrdenes(ArrayList<String> List, DefaultListModel model){
        
        String linea;
        for(int i=0;i<=List.size()-1;i++){
            linea= List.get(i);
            String[] vec= linea.split(";");
            model.addElement("CODIGO: "+vec[0]);
            model.addElement("ESTADO: "+vec[1]);
            model.addElement("TIPO: "+vec[2]);
            if("Crudo".equals(vec[2])==true){
                model.addElement("TIPO DE CRUDO: "+vec[3]);
                model.addElement("CANTIDAD: "+vec[4]);
                model.addElement("POZO ORIGEN: "+vec[5]);
                model.addElement("FECHA EXTRACCIÓN: "+vec[6]);
                model.addElement("CLIENTE: "+vec[7]);
            }
            else
                if("Derivados Refinados".equals(vec[2])==true){
                    model.addElement("TIPO DERIVADO: "+vec[3]);
                    model.addElement("INDICE DE CALIDAD: "+vec[4]);
                    model.addElement("CANTIDAD: "+vec[5]);
                    model.addElement("POZO ORIGEN: "+vec[6]);
                    model.addElement("FECHA EXTRACCIÓN: "+vec[7]);
                    model.addElement("FECHA PROCESAMIENTO: "+vec[8]);
                    model.addElement("REFINERIA: "+vec[9]);
                    model.addElement("CLIENTE: "+vec[10]);
                }
            else
                    if("Carga General".equals(vec[2])==true){
                        model.addElement("DESCRIPCIÓN: "+vec[3]);
                        model.addElement("CANTIDAD: "+vec[4]);
                        model.addElement("AREA: "+vec[5]);
                        model.addElement("PESO: "+vec[6]);
                        model.addElement("TIPO UNIDADES: "+vec[7]);
                        model.addElement("CLIENTE: "+vec[8]);
                    }

            model.addElement("------------------------------------------------------------");
        }
        }
    
    public void busOrdenCod(String cod, ArrayList<String> List,DefaultListModel model){
        
        //DefaultListModel model=new DefaultListModel();
        String linea;int i=0;boolean sw=false;
        while(i<=List.size()-1 && sw==false){
            linea= List.get(i);
            String[] vec= linea.split(";");

            if(cod.equals(vec[0])==true){
                sw=true;
                if("Crudo".equals(vec[2])==true){
                    model.addElement("CODIGO: "+vec[0]);
                    model.addElement("ESTADO: "+vec[1]);
                    model.addElement("TIPO: "+vec[2]);
                    model.addElement("TIPO DE CRUDO: "+vec[3]);
                    model.addElement("CANTIDAD: "+vec[4]);
                    model.addElement("POZO ORIGEN: "+vec[5]);
                    model.addElement("FECHA EXTRACCIÓN: "+vec[6]);
                    model.addElement("CLIENTE: "+vec[7]);
                }
                else
                    if("Derivados Refinados".equals(vec[2])==true){
                        model.addElement("CODIGO: "+vec[0]);
                        model.addElement("ESTADO: "+vec[1]);
                        model.addElement("TIPO: "+vec[2]);
                        model.addElement("TIPO DERIVADO: "+vec[3]);
                        model.addElement("INDICE DE CALIDAD: "+vec[4]);
                        model.addElement("CANTIDAD: "+vec[5]);
                        model.addElement("POZO ORIGEN: "+vec[6]);
                        model.addElement("FECHA EXTRACCIÓN: "+vec[7]);
                        model.addElement("FECHA PROCESAMIENTO: "+vec[8]);
                        model.addElement("REFINERIA: "+vec[9]);
                        model.addElement("CLIENTE: "+vec[10]);
                    }
                else
                        if("Carga General".equals(vec[2])==true){
                            model.addElement("CODIGO: "+vec[0]);
                            model.addElement("ESTADO: "+vec[1]);
                            model.addElement("TIPO: "+vec[2]);
                            model.addElement("DESCRIPCIÓN: "+vec[3]);
                            model.addElement("CANTIDAD: "+vec[4]);
                            model.addElement("AREA: "+vec[5]);
                            model.addElement("PESO: "+vec[6]);
                            model.addElement("TIPO UNIDADES: "+vec[7]);
                            model.addElement("CLIENTE: "+vec[8]);
                        }
            }
            i++;
        }
    }
    
    public void busOrdenCli(String nom,ArrayList<String> List,DefaultListModel model){
        
        String linea;int i=0;
        while(i<=List.size()-1){
            linea= List.get(i);
            String[] vec= linea.split(";");
            if("Crudo".equals(vec[2])==true){
               if(nom.equals(vec[7])==true){
                    model.addElement("CODIGO: "+vec[0]);
                    model.addElement("ESTADO: "+vec[1]);
                    model.addElement("TIPO: "+vec[2]);
                    model.addElement("TIPO DE CRUDO: "+vec[3]);
                    model.addElement("CANTIDAD: "+vec[4]);
                    model.addElement("POZO ORIGEN: "+vec[5]);
                    model.addElement("FECHA EXTRACCIÓN: "+vec[6]);
                    model.addElement("CLIENTE: "+vec[7]);
               }
            }
            else
                if("Derivados Refinados".equals(vec[2])==true){
                    if(nom.equals(vec[10])==true){
                        model.addElement("CODIGO: "+vec[0]);
                        model.addElement("ESTADO: "+vec[1]);
                        model.addElement("TIPO: "+vec[2]);
                        model.addElement("TIPO DERIVADO: "+vec[3]);
                        model.addElement("INDICE DE CALIDAD: "+vec[4]);
                        model.addElement("CANTIDAD: "+vec[5]);
                        model.addElement("POZO ORIGEN: "+vec[6]);
                        model.addElement("FECHA EXTRACCIÓN: "+vec[7]);
                        model.addElement("FECHA PROCESAMIENTO: "+vec[8]);
                        model.addElement("REFINERIA: "+vec[9]);
                        model.addElement("CLIENTE: "+vec[10]);
                    }
                }
            else
                    if("Carga General".equals(vec[2])==true){
                        if(nom.equals(vec[8])==true){
                            model.addElement("CODIGO: "+vec[0]);
                            model.addElement("ESTADO: "+vec[1]);
                            model.addElement("TIPO: "+vec[2]);
                            model.addElement("DESCRIPCIÓN: "+vec[3]);
                            model.addElement("CANTIDAD: "+vec[4]);
                            model.addElement("AREA: "+vec[5]);
                            model.addElement("PESO: "+vec[6]);
                            model.addElement("TIPO UNIDADES: "+vec[7]);
                            model.addElement("CLIENTE: "+vec[8]);
                        }
                    }
                    model.addElement("-----------------------------------------------------");
            i++;
        }

    }
    
    public void busOrdTipo(String tipo,ArrayList<String> List,DefaultListModel model){
        
        String linea;
        for(int i=0;i<=List.size()-1;i++){
            linea= List.get(i);
            String[] vec= linea.split(";");
            if(tipo.equals(vec[2])==true){
                if("Crudo".equals(vec[2])==true){
                    model.addElement("CODIGO: "+vec[0]);
                    model.addElement("ESTADO: "+vec[1]);
                    model.addElement("TIPO: "+vec[2]);
                    model.addElement("TIPO DE CRUDO: "+vec[3]);
                    model.addElement("CANTIDAD: "+vec[4]);
                    model.addElement("POZO ORIGEN: "+vec[5]);
                    model.addElement("FECHA EXTRACCIÓN: "+vec[6]);
                    model.addElement("CLIENTE: "+vec[7]);
                }
                else
                    if("Derivados Refinados".equals(vec[2])==true){
                        model.addElement("CODIGO: "+vec[0]);
                        model.addElement("ESTADO: "+vec[1]);
                        model.addElement("TIPO: "+vec[2]);
                        model.addElement("TIPO DERIVADO: "+vec[3]);
                        model.addElement("INDICE DE CALIDAD: "+vec[4]);
                        model.addElement("CANTIDAD: "+vec[5]);
                        model.addElement("POZO ORIGEN: "+vec[6]);
                        model.addElement("FECHA EXTRACCIÓN: "+vec[7]);
                        model.addElement("FECHA PROCESAMIENTO: "+vec[8]);
                        model.addElement("REFINERIA: "+vec[9]);
                        model.addElement("CLIENTE: "+vec[10]);
                    }
                else
                        if("Carga General".equals(vec[2])==true){
                            model.addElement("CODIGO: "+vec[0]);
                            model.addElement("ESTADO: "+vec[1]);
                            model.addElement("TIPO: "+vec[2]);
                            model.addElement("DESCRIPCIÓN: "+vec[3]);
                            model.addElement("CANTIDAD: "+vec[4]);
                            model.addElement("AREA: "+vec[5]);
                            model.addElement("PESO: "+vec[6]);
                            model.addElement("TIPO UNIDADES: "+vec[7]);
                            model.addElement("CLIENTE: "+vec[8]);
                        }
                model.addElement("----------------------------------------------------------");
            }
        }
    }
    
    public void busOrdEstado(String estado,ArrayList<String> List,DefaultListModel model){
        
        String linea;
        for(int i=0;i<=List.size()-1;i++){
            linea= List.get(i);
            String[] vec= linea.split(";");
            if(estado.equals(vec[1])==true){
                if("Crudo".equals(vec[2])==true){
                    model.addElement("CODIGO: "+vec[0]);
                    model.addElement("ESTADO: "+vec[1]);
                    model.addElement("TIPO: "+vec[2]);
                    model.addElement("TIPO DE CRUDO: "+vec[3]);
                    model.addElement("CANTIDAD: "+vec[4]);
                    model.addElement("POZO ORIGEN: "+vec[5]);
                    model.addElement("FECHA EXTRACCIÓN: "+vec[6]);
                    model.addElement("CLIENTE: "+vec[7]);
                }
                else
                    if("Derivados Refinados".equals(vec[2])==true){
                        model.addElement("CODIGO: "+vec[0]);
                        model.addElement("ESTADO: "+vec[1]);
                        model.addElement("TIPO: "+vec[2]);
                        model.addElement("TIPO DERIVADO: "+vec[3]);
                        model.addElement("INDICE DE CALIDAD: "+vec[4]);
                        model.addElement("CANTIDAD: "+vec[5]);
                        model.addElement("POZO ORIGEN: "+vec[6]);
                        model.addElement("FECHA EXTRACCIÓN: "+vec[7]);
                        model.addElement("FECHA PROCESAMIENTO: "+vec[8]);
                        model.addElement("REFINERIA: "+vec[9]);
                        model.addElement("CLIENTE: "+vec[10]);
                    }
                else
                        if("Carga General".equals(vec[2])==true){
                            model.addElement("CODIGO: "+vec[0]);
                            model.addElement("ESTADO: "+vec[1]);
                            model.addElement("TIPO: "+vec[2]);
                            model.addElement("DESCRIPCIÓN: "+vec[3]);
                            model.addElement("CANTIDAD: "+vec[4]);
                            model.addElement("AREA: "+vec[5]);
                            model.addElement("PESO: "+vec[6]);
                            model.addElement("TIPO UNIDADES: "+vec[7]);
                            model.addElement("CLIENTE: "+vec[8]);
                        }
                model.addElement("-------------------------------------------------");
            }
        }
    }
}
