/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package labpoo;

import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author sebastiancaicedo
 */
public class General extends Orden{
    
    String descripcion;
    String area;
    String peso;
    String tipoUnidades;
    
    public void crearOrden(General obj, ArrayList<String> List,String desc,String cant,String are,String pes,String tipuni,String cli){
        
        obj.numRef=obj.asignarCodigo(List)+"";
        obj.estado="Pendiente";
        obj.tipo="Carga General";
        obj.descripcion=desc;
        obj.cantidad=cant;
        obj.area=are;
        obj.peso=pes;
        obj.tipoUnidades=tipuni;
        obj.cliente=cli;
        
        asignarList(obj,List);
        
    }
    
    private void asignarList(General obj,ArrayList<String> List){
        
       String campo;
       campo= obj.numRef+";"+obj.estado+";"+obj.tipo+";"+obj.descripcion+";"+obj.cantidad+";"+obj.area+";"+obj.peso+";"+obj.tipoUnidades+";"+obj.cliente+";"+"-";
       List.add(campo);
    }
    
    public boolean verifCant(String area,String peso){//HAcer trycatch en la conversion del area y peso
        if(Integer.parseInt(peso)> 100 && Integer.parseInt(area)> 2000){
            return false;
        }
        else
        {
            return true;
        }
    }   
}
