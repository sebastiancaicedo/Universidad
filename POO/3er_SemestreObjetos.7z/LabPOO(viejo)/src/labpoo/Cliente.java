/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package labpoo;

import java.util.ArrayList;
import javax.swing.DefaultListModel;



/**
 *
 * @author sebastiancaicedo
 */
public class Cliente {
    String nombre;
    
    
    ArrayList<String> clientes= new ArrayList();
    
    public void crearCliente(String nombre,ArrayList<String> List){
        Cliente c=new Cliente();
        c.nombre = nombre;
        
        asignarList(c,List);
        
    }
    
    public void asignarList(Cliente obj, ArrayList<String> List){
        
        List.add(obj.nombre);
    }
    

    
    
    public boolean verifExist(String nombre, ArrayList<String> clientes){
        
        if(clientes.contains(nombre)==true){
            return false;
        }
        else
        {
            return true;
        }
    }
    
    public void listarClientes(ArrayList<String> List,DefaultListModel model){
        
        for(int i=0;i<=List.size()-1;i++){
            model.addElement(List.get(i));
            model.addElement("--------------------");
        }
    }
    
}
