/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package labpoo;

import java.util.ArrayList;

/**
 *
 * @author sebastiancaicedo
 */
public class Crudo extends Orden {
    
    String tipoCrudo;
    String pozoOrigen;
    String fechaExtr;
    
    public void crearOrden(Crudo obj,ArrayList<String> List,String tcrudo,String cant,String pozo,String fechaEx,String cliente){
        obj.numRef= obj.asignarCodigo(List)+"";
        obj.estado= "Pendiente";
        obj.tipo= "Crudo";
        obj.tipoCrudo= tcrudo;
        obj.cantidad= cant;
        obj.pozoOrigen= pozo;
        obj.fechaExtr=fechaEx;
        obj.cliente= cliente;
        
        agregarList(obj,List);

        
    }
    //Crear una interface entre orden derivado y carga pra tener metodo crear orden;
    
    
    private void agregarList(Crudo obj, ArrayList<String> List){
        String campo;
        campo= (obj.numRef+"")+";"+obj.estado+";"+obj.tipo+";"+obj.tipoCrudo+";"+(obj.cantidad+"")+";"+obj.pozoOrigen+";"+obj.fechaExtr+";"+obj.cliente+";"+"-";
        List.add(campo);
    }
    
    public boolean verifCant(String cant){
        
        if(Integer.parseInt(cant)> 50000){
            return false;
        }
        else
        {
            return true;
        }
    }
    

    
}
