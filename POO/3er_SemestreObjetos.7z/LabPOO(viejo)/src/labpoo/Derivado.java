/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package labpoo;

import java.util.ArrayList;

/**
 *
 * @author sebastiancaicedo
 */
public class Derivado extends Orden{  
    String tipoDer;
    String indCalidad;
    String pozoOrigen;
    String fechaExtr;
    String refineria;
    String fechaProces;
    
    public void CrearOrden(Derivado obj,ArrayList<String> List, String tder, String indcal,String cant,String pozo,String feEx,String fePro,String refi,String cli){
        
        obj.numRef=obj.asignarCodigo(List)+"";
        obj.estado="Pendiente";
        obj.tipo="Derivados Refinados";
        obj.tipoDer=tder;
        obj.indCalidad=indcal;
        obj.cantidad=cant;
        obj.pozoOrigen=pozo;
        obj.fechaExtr=feEx;
        obj.fechaProces=fePro;
        obj.refineria=refi;
        obj.cliente=cli;
        
        asignarList(obj,List);
    }
    
    private void asignarList(Derivado obj,ArrayList<String> List){
        
        String campo;
        campo=obj.numRef+";"+obj.estado+";"+obj.tipo+";"+obj.tipoDer+";"+obj.indCalidad+";"+obj.cantidad+";"+obj.pozoOrigen+";"+obj.fechaExtr+";"+obj.fechaProces+";"+obj.refineria+";"+obj.cliente+";"+"-";
        List.add(campo);
    }
    
    public boolean verifCant(String cant){
        if(Integer.parseInt(cant)> 50000){
            return false;
        }
        else
        {
            return true;
        }
    }
}
