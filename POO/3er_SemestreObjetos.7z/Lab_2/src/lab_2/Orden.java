/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_2;

/**
 *
 * @author sebastiancaicedo
 */
public class Orden {
    public String tipo;
    public int cantidad;
    public String estado;
    public int numRef;
    public String cliente;
}
