/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_2;

/**
 *
 * @author sebastiancaicedo
 */
public class Crudo extends Orden {
    String tipoCrudo;
    String pozoOrigen;
    String fechaExtr;    
}
