/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_2;

/**
 *
 * @author sebastiancaicedo
 */
public class Derivado extends Orden {
    String tipoDer;
    double indCalidad;
    String pozoOrigen;
    String fechaExtr;
    String refineria;
    String fechaProces;
    
}
