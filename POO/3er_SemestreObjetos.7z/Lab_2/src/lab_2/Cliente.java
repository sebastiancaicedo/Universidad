/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_2;

import java.util.ArrayList;

/**
 *
 * @author sebastiancaicedo
 */
public class Cliente {
    
    String nombre;
    double cargaTotal;
    ArrayList<String> ordenes= new ArrayList<String>();
    

    
    public boolean verifExist(String nombre, ArrayList<String> lista){
        
        if(lista.contains("nombre")==true){
            return false;
        }
        else
        {
            return true;
        }
    }
}


