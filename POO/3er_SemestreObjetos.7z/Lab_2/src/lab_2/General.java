/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_2;

/**
 *
 * @author sebastiancaicedo
 */
public class General {
    String descripcion;
    double area;
    double peso;
    String tipoUnidades;
}
