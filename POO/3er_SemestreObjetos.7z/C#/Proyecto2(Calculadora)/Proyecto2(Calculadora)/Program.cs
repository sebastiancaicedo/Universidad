﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto2_Calculadora_
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, op = 0;
            do
            {
                Console.WriteLine("---------------CALCULADORA-------------\n\n");
                Console.WriteLine("1.Suma\n2.Resta\n3.Multiplicación\n4.Division\n5.Salir\n");
                Console.Write("Escoja una opcion: ");
                op= Convert.ToInt32(Console.ReadLine());

                if (op == 5)
                {
                    Console.WriteLine("♠♠♠♠♠♠♠Hasta La Proxima♠♠♠♠♠♠♠♠");
                }
                else
                {
                    Console.Write("Primer Numero: ");
                    num1 = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Segundo Numero: ");
                    num2 = Convert.ToInt32(Console.ReadLine());
                    Console.Write("El resultado es: ");
                    if (op == 1)
                    {
                        Console.WriteLine(num1 + num2);
                    }
                    else
                        if (op == 2)
                        {
                            Console.WriteLine(num1 - num2);
                        }
                        else
                            if (op == 3)
                            {
                                Console.WriteLine(num1 * num2);
                            }
                            else
                                if (op == 4)
                                {
                                    Console.WriteLine(num1 / num2);
                                }
                }
            } while (op != 5);
            Console.ReadKey();
        }

    }
}
