
package prueba2;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Prueba2 {
    
    public void escmensaje(String men){
        System.out.println(men);
    }
    
    public String leerMensaje(String men){
        String temp;
        
        BufferedReader bf = new BufferedReader(
                new InputStreamReader(System.in));
        
        escmensaje(men);
        
        try {
            temp=bf.readLine();
        } catch (Exception ex) {ex.printStackTrace(); temp="";}
        
        return temp;
    }
    
    public int leerInt(String men)
    { 
        String temp = leerMensaje(men);
        int tempNum = 0;
        try{ 
            tempNum = Integer.parseInt(temp);
        }catch(Exception ex){ex.printStackTrace();tempNum=0;} 
        return tempNum;
    }
    
    public int suma(int a, int b){
        return a+b;
    }
    
    public void principal(){
        int num1, num2;
        num1= leerInt("Digite un numero: ");
        num2= leerInt("Digite otro numero: ");
        leerMensaje("la suma es igual a: "+this.suma(num1, num2));
    }

    public static void main(String[] args) {
        Prueba2 p=new Prueba2();
        p.principal();

    }
}
