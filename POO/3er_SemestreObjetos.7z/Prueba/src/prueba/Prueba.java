
package prueba;

public class Prueba {
    
    public void avanzar(){
        System.out.println("La prueba está avanzando");
    }
    
    public void encender(){
        System.out.println("La prueba está encendida");
    }
    
    public void detener(){
        System.out.println("La prueba se detuvo");
    }
    

    public static void main(String[] args) {
        Prueba p= new Prueba();
        p.encender();
        p.avanzar();
        p.detener();
    }
}
