#pragma once

namespace Laboratorio2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
//----------------------------------------------------------------------------------------------------------
    //VARIABLES
	int Dir[400],x1,y1,x2,y2,Mat[20][20];
	int Laberinto1[20][20]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1, 
							1,0,0,0,0,1,0,1,0,1,0,1,0,0,1,0,1,0,1,1,
							1,1,1,0,0,1,0,1,0,1,0,1,1,0,1,0,1,0,0,1,
							1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,1,
							1,0,0,1,1,0,1,0,1,1,0,0,0,0,1,0,0,0,0,1,
							1,0,0,0,1,1,1,0,1,0,0,1,1,1,0,0,1,0,0,1,
							1,1,1,0,1,0,1,0,1,0,1,1,0,1,0,1,1,1,1,1,
							1,0,1,0,1,0,1,1,1,1,1,1,0,0,0,0,1,0,0,1,
							1,0,0,0,1,0,1,0,1,0,0,1,0,1,0,0,1,0,1,1,
							1,0,0,1,1,0,1,0,0,0,0,0,0,1,1,0,0,0,0,1,
							1,0,0,0,0,0,1,0,1,1,1,0,0,0,0,0,1,1,1,1,
							1,0,1,1,1,0,1,0,0,0,1,1,1,1,0,0,1,0,1,1,
							1,1,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,1,//12
							1,0,1,0,1,0,0,0,0,0,1,1,1,1,0,0,1,0,0,1,
							1,0,1,0,1,1,1,0,1,0,1,0,0,0,0,1,1,1,0,1,
							1,0,0,0,0,0,1,0,1,1,1,1,0,1,0,0,0,1,0,1,
							1,1,1,1,1,0,0,0,0,0,1,0,0,1,0,0,1,1,0,1,
							1,0,0,0,1,1,1,0,1,0,1,0,1,1,0,0,0,1,0,1,
							1,0,1,0,0,0,0,0,1,0,0,0,0,1,0,1,0,1,0,1,
							1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
	
	int Laberinto2[20][20]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
							1,1,0,1,1,0,0,1,1,0,0,0,1,0,0,1,1,1,1,1,
							1,0,0,0,1,1,0,0,0,0,1,0,1,1,0,0,0,0,0,1,
							1,0,1,0,0,0,0,1,1,1,1,0,1,0,0,1,1,1,0,1,
							1,0,1,1,1,0,0,0,0,0,0,0,0,0,1,1,0,1,0,1,
							1,0,1,0,0,1,0,1,1,0,1,1,1,0,0,0,0,0,0,1,
							1,0,0,1,0,1,1,1,0,0,1,1,1,1,0,1,0,1,1,1,
							1,1,0,0,0,0,1,1,0,1,1,0,0,1,1,1,0,0,0,1,
							1,1,1,1,1,0,0,0,0,1,1,0,1,0,1,1,0,1,0,1,
							1,0,1,0,1,1,0,1,0,0,0,0,0,0,0,1,0,1,1,1,
							1,0,1,0,0,0,0,0,0,1,0,1,1,1,0,1,0,0,0,1,
							1,0,0,0,1,0,1,1,0,1,1,1,0,0,0,0,0,1,1,1,
							1,0,1,0,0,1,0,0,0,0,1,0,1,0,1,0,1,0,1,1,
							1,0,1,1,0,0,0,1,1,0,0,0,0,0,0,1,0,0,0,1,
							1,0,1,0,0,1,1,1,1,0,0,1,0,1,0,0,0,1,0,1,
							1,0,0,0,1,0,1,0,1,1,0,1,0,1,0,1,1,1,1,1,
							1,1,1,1,0,0,0,0,0,1,0,0,1,0,0,0,1,1,0,1,
							1,1,0,1,1,0,1,1,0,1,0,1,0,0,1,0,0,0,0,1,
							1,0,0,0,0,0,1,0,0,0,0,1,0,0,1,1,0,1,1,1,
							1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};

	int Laberinto3[20][20]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
							1,1,1,0,0,1,1,1,1,0,0,0,1,1,1,0,0,0,0,1,
							1,0,1,1,0,0,1,1,0,0,1,0,0,1,0,1,0,1,1,1,
							1,0,1,1,1,0,0,0,0,1,1,1,0,0,0,1,0,1,1,1,
							1,0,1,0,0,0,0,1,0,0,1,0,0,0,1,1,0,0,0,1,
							1,0,1,1,0,1,1,1,0,1,1,0,1,0,0,0,0,1,0,1,
							1,0,0,0,0,0,1,0,0,0,0,1,0,0,1,0,0,1,0,1,
							1,0,1,0,1,1,1,0,1,0,1,1,1,0,0,0,1,0,0,1,
							1,0,1,1,0,0,0,0,0,0,0,1,0,0,1,0,0,0,1,1,
							1,1,1,1,0,1,0,1,1,1,1,0,0,1,1,1,0,1,1,1,
							1,0,0,0,0,1,0,0,0,0,1,0,1,1,1,1,0,0,0,1,
							1,1,1,1,0,1,1,0,1,1,0,0,0,1,1,1,1,1,1,1,
							1,0,0,1,0,0,0,0,1,0,0,1,1,0,1,1,0,0,1,1,
							1,1,1,1,0,1,1,0,0,0,1,1,0,0,0,1,1,1,1,1,
							1,1,0,1,1,1,1,1,1,0,1,1,0,1,0,0,0,0,0,1,
							1,0,0,0,0,1,0,1,0,0,0,0,0,1,0,1,1,0,1,1,
							1,1,1,1,0,1,0,0,0,1,0,1,1,1,0,1,1,0,0,1,
							1,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,1,1,
							1,1,0,0,1,1,0,0,1,0,1,1,0,0,1,0,1,1,0,1,
							1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};


//----------------------------------------------------------------------------------------------------------

	/// <summary>
	/// Resumen de Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	protected: 
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::DataGridView^  dataGridView1;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::TextBox^  textBox3;
	private: System::Windows::Forms::TextBox^  textBox4;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;






















	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(156, 49);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Mostrar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(521, 286);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(114, 38);
			this->button2->TabIndex = 1;
			this->button2->Text = L"Buscar Soluci�n";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// dataGridView1
			// 
			this->dataGridView1->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::AllCells;
			this->dataGridView1->AutoSizeRowsMode = System::Windows::Forms::DataGridViewAutoSizeRowsMode::AllCells;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(46, 133);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->Size = System::Drawing::Size(469, 427);
			this->dataGridView1->TabIndex = 2;
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(402, 30);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(32, 20);
			this->textBox1->TabIndex = 3;
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(440, 30);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(33, 20);
			this->textBox2->TabIndex = 4;
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(402, 56);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(32, 20);
			this->textBox3->TabIndex = 5;
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(440, 56);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(33, 20);
			this->textBox4->TabIndex = 6;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(271, 37);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(125, 13);
			this->label1->TabIndex = 7;
			this->label1->Text = L"Coordenadas de Entrada";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(279, 59);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(117, 13);
			this->label2->TabIndex = 8;
			this->label2->Text = L"Coordenadas de Salida";
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(3) {L"A. Laberinto 1.", L"B. Laberinto 2.", L"C. Laberinto 3."});
			this->comboBox1->Location = System::Drawing::Point(29, 49);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(121, 21);
			this->comboBox1->TabIndex = 9;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(399, 14);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(23, 13);
			this->label3->TabIndex = 10;
			this->label3->Text = L"Fila";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(425, 14);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(48, 13);
			this->label4->TabIndex = 11;
			this->label4->Text = L"Columna";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(117, 117);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(397, 13);
			this->label5->TabIndex = 12;
			this->label5->Text = L"1      2     3     4    5     6     7    8      9     10   11   12   13   14   15" 
				L"   16   17   18   19";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(93, 14);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(107, 13);
			this->label6->TabIndex = 13;
			this->label6->Text = L"Seleccione Laberinto";
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(479, 28);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(36, 23);
			this->button3->TabIndex = 14;
			this->button3->Text = L"Verif";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(479, 56);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(36, 23);
			this->button4->TabIndex = 15;
			this->button4->Text = L"Verif";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(964, 597);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->textBox4);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
//---------------------------------------------------------------------------------------------------------
    //FUNCIONES Y SUBRUTINAS
        void MostrarMat(int M[20][20], int i,int j){
            if(i<20){
                if(j<20){
                    dataGridView1[j, i]->Value = M[i][j];
                    j++;
                    MostrarMat(M,i,j);
                }
                else
                {
                    j=0;
                    i++;
                    MostrarMat(M,i,j);
                }
            }
        }

        void Color(int M[20][20],int i,int j){
            if(i<20){
                if(j<20){
                    if(M[i][j]==0){
                        dataGridView1[j, i]->Style->BackColor = Color::White;
						dataGridView1[j, i]->Style->ForeColor = Color::White;
                    }
                    else
                        if(M[i][j]==1){
                            dataGridView1[j, i]->Style->BackColor = Color::Black;
							dataGridView1[j, i]->Style->ForeColor = Color::Black;
                        }
                        else
                            if(M[i][j]==3){
                                dataGridView1[j, i]->Style->BackColor = Color::Blue;
								dataGridView1[j, i]->Style->ForeColor = Color::Blue;
                            }
                            else
                                if(M[i][j]==4){
                                    dataGridView1[j, i]->Style->BackColor = Color::Red;
									dataGridView1[j, i]->Style->ForeColor = Color::Red;
                                }
                                else
                                    if(M[i][j]==5||M[i][j]==9){
                                        dataGridView1[j, i]->Style->BackColor = Color::Yellow;
										dataGridView1[j, i]->Style->ForeColor = Color::Yellow;
                                    }
                                j++;
                                Color(M,i,j);
                    }
                    else
                    {
                        j=0;
                        i++;
                        Color(M,i,j);
                    }
                }
        }

        void Solucion(int M[20][20],int i,int j,int V[400],int t){
            int dir;
            if(M[i][j]==5||M[i][j]==4){
                if(M[i-1][j]==9){
                    M[i-1][j]=5;
                    Solucion(M,i-1,j,V,t);
                }
                else
                    if(M[i][j+1]==9){
                        M[i][j+1]=5;
                        Solucion(M,i,j+1,V,t);
                    }
                    else
                        if(M[i+1][j]==9){
                            M[i+1][j]=5;
                            Solucion(M,i+1,j,V,t);
                        }
                        else
                            if(M[i][j-1]==9){
                                M[i][j-1]=5;
                                Solucion(M,i,j-1,V,t);
                            }
            }
            else
                if(M[i][j]==0||M[i][j]==3||M[i][j]==9){
                    M[i][j]=9;
                    if(M[i-1][j]==0||M[i-1][j]==4){
                        dir=1;
                        t++;
                        V[t]=dir;
                        Solucion(M,i-1,j,V,t);
                    }
                    else
                        if(M[i][j+1]==0||M[i][j+1]==4){
                            dir=2;
                            t++;
                            V[t]=dir;
                            Solucion(M,i,j+1,V,t);
                        }
                        else
                            if(M[i+1][j]==0||M[i+1][j]==4){
                                dir=3;
                                t++;
                                V[t]=dir;
                                Solucion(M,i+1,j,V,t);
                            }
                            else
                                if(M[i][j-1]==0||M[i][j-1]==4){
                                    dir=4;
                                    t++;
                                    V[t]=dir;
                                    Solucion(M,i,j-1,V,t);
                                }
                                else
                                {
                                    M[i][j]=8;
                                    if(V[t]==1){
                                        Solucion(M,i+1,j,V,t-1);
                                    }
                                    else
                                        if(V[t]==2){
                                            Solucion(M,i,j-1,V,t-1);
                                        }
                                        else
                                            if(V[t]==3){
                                                Solucion(M,i-1,j,V,t-1);
                                            }
                                            else
                                                if(V[t]==4){
                                                    Solucion(M,i,j+1,V,t-1);
                                                }
                                }
                }
                else
                    if(M[i][j]==8){
                        MessageBox::Show("No tiene Solucion");
                    }
        }
//----------------------------------------------------------------------------------------------------------
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				 int opcion=comboBox1->SelectedIndex;
				 dataGridView1->RowCount = 20;
                 dataGridView1->ColumnCount = 20;
				 switch(opcion){
				 case 0:
					 MostrarMat(Laberinto1,0,0);
					 Color(Laberinto1,0,0);
					 break;
				 case 1:
					 MostrarMat(Laberinto2,0,0);
					 Color(Laberinto2,0,0);
					 break;
				 case 2:
					 MostrarMat(Laberinto3,0,0);
					 Color(Laberinto3,0,0);
				 }
			 }
	private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
				 int opcion=comboBox1->SelectedIndex;
				 switch(opcion){
					 case 0:
							 Laberinto1[x1][y1]=3;
							 Laberinto1[x2][y2]=4;
							 Solucion(Laberinto1,x1,y1,Dir,0);
							 Laberinto1[x1][y1]=3;
							 MostrarMat(Laberinto1,0,0);
							 Color(Laberinto1,0,0);
						 break;
					 case 1:
							 Laberinto2[x1][y1]=3;
							 Laberinto2[x2][y2]=4;
							 Solucion(Laberinto2,x1,y1,Dir,0);
							 Laberinto2[x1][y1]=3;
							 MostrarMat(Laberinto2,0,0);
							 Color(Laberinto2,0,0);
						 break;
					 case 2:
							 Laberinto3[x1][y1]=3;
							 Laberinto3[x2][y2]=4;
							 Solucion(Laberinto3,x1,y1,Dir,0);
							 Laberinto3[x1][y1]=3;
							 MostrarMat(Laberinto3,0,0);
							 Color(Laberinto3,0,0);
						 break;
				 }
			 }

private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
			 int opcion=comboBox1->SelectedIndex;
			 x1= System::Int32::Parse(textBox1->Text);
			 y1= System::Int32::Parse(textBox2->Text);
			 switch(opcion){
			 case 0:
				 if(Laberinto1[x1][y1]==0){
					 Laberinto1[x1][y1]=3;
					 MostrarMat(Laberinto1,0,0);
					 Color(Laberinto1,0,0);
				 }
				 else
				 {
					 MessageBox::Show("No se puede ubicar la Entrada ahi");
				 }
				 break;
			 case 1:
				 if(Laberinto2[x1][y1]==0){
					 Laberinto2[x1][y1]=3;
					 MostrarMat(Laberinto2,0,0);
					 Color(Laberinto2,0,0);
				 }
				 else
				 {
					 MessageBox::Show("No se puede ubicar la Entrada ahi");
				 }
				 break;
			 case 2:
				 if(Laberinto3[x1][y1]==0){
					 Laberinto3[x1][y1]=3;
					 MostrarMat(Laberinto3,0,0);
					 Color(Laberinto3,0,0);
				 }
				 else
				 {
					 MessageBox::Show("No se puede ubicar la Entrada ahi");
				 }
				 break;
			 }
			 
		 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
			 int opcion=comboBox1->SelectedIndex;
			 x2= System::Int32::Parse(textBox3->Text);
			 y2= System::Int32::Parse(textBox4->Text);
			 switch(opcion){
			 case 0:
				 if(Laberinto1[x2][y2]==0){
					 Laberinto1[x2][y2]=4;
					 MostrarMat(Laberinto1,0,0);
					 Color(Laberinto1,0,0);
				 }
				 else
				 {
					 MessageBox::Show("No se puede ubicar la salida ahi");
				 }
				 break;
			 case 1:
				 if(Laberinto2[x2][y2]==0){
					 Laberinto2[x2][y2]=4;
					 MostrarMat(Laberinto2,0,0);
					 Color(Laberinto2,0,0);
				 }
				 else
				 {
					 MessageBox::Show("No se puede ubicar la salida ahi");
				 }
				 break;
			 case 2:
				 if(Laberinto3[x2][y2]==0){
					 Laberinto3[x2][y2]=4;
					 MostrarMat(Laberinto3,0,0);
					 Color(Laberinto3,0,0);
				 }
				 else
				 {
					 MessageBox::Show("No se puede ubicar la salida ahi");
				 }
				 break;
			 }
		 }

		 
};
}

