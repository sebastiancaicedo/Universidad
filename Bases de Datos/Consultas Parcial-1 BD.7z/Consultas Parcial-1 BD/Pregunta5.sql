select top 1 SUM(soh.SubTotal) as totalVentas, sterri.SalesYTD, sterri.Name
from Sales.SalesTerritory as sterri, Sales.SalesOrderHeader as soh
where soh.TerritoryID = sterri.TerritoryID
group by sterri.SalesYTD, sterri.Name
order by totalVentas desc
