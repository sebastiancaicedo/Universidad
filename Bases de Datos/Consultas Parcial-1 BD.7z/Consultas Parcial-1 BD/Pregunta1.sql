select Top 1 SUM(soh.SubTotal) as subTotal, cc.CardType----distinct cc.CardType, 
from Sales.CreditCard as cc, Sales.SalesOrderHeader as soh
where cc.CreditCardID = soh.CreditCardID
group by cc.CardType
order by subTotal desc