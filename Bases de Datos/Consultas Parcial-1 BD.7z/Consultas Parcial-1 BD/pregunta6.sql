select Top 1 avg(e.SickLeaveHours) as promHorasTipo, e.JobTitle
from HumanResources.Employee as e
group by e.JobTitle
order by promHorasTipo