Calculadora Uninorte.
Hecha por la clase de Algoritmos y Complejidad del periodo 201530



Componentes de la ventana:

Operando 1: TextArea d�nde se escribe el primer operando.

Archivo: bot�n a la derecha del TextArea que habilita la opci�n de buscar el valor del operando 1 en un archivo de texto (.txt).

Operando 2: TextArea d�nde se escribe el segundo operando.

Archivo: bot�n a la derecha del TextArea que habilita la opci�n de buscar el valor del operando 2 en un archivo de texto (.txt).

Operaci�n: ComboBox para indicar la operaci�n que va a hacer la calculadora.

Aceptar: Bot�n para que el programa efect�e la operaci�n indicada, con los par�metros indicados.

Radianes: CheckBox visible cuando se elige alguna operaci�n trigonom�trica en el ComboBox, indica si el par�metro est� en radianes o no.

Ans: Bot�n para obtener el valor en el TextArea del resultado y escribirlo en el TextArea del operando 1.

Resultado: TextArea de solo lectura para mostrar el resultado de la operaci�n.

Exportar: Bot�n para guardar la �ltima respuesta en un archivo de texto (.txt) en la ruta elegida.

Clear: Bot�n para limpiar el texto escrito en todos los TextArea.

Formato de operaciones con vectores: los componentes deben separarse por una coma (',') y solo una coma. e.g 1,3,4,5,6,8

Formato de operaciones con n�meros con decimales: los decimales deben escribirse con un punto ('.') antepuesto. e.g 2.3412
