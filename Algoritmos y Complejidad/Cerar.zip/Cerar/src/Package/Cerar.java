/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Package;

/**
 *
 * @author sebastiancaicedo
 */
public class Cerar {
    
    
    public static void main(String[] args) {
        int Mat[][]= new int[500][500];
        for (int i = 0; i < 500; i++) {
            Mat[i][i]=1;
            System.out.println(Mat[i][i]);
        }
    }
    
    
    
}
